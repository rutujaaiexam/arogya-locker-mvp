# Arogya Locker - Your Family Health Guardian

A secure medical locker and health management application for individuals and families. Store prescriptions, track medications, manage emergency cards, and access your health information anytime, anywhere.

## 🚀 Quick Start on Replit

1. **Clone or Import this project to Replit**
2. **Run the application:**
   ```bash
   npm run dev
   ```
3. **Access the app** - The app will automatically open in your browser at the Replit preview URL

That's it! The app is ready to use.

## 📱 MVP Features

### ✅ Implemented in this Version

- **Demo Login System** - Phone number + OTP verification (accepts any 6-digit code for demo)
- **Family Profiles** - Create, manage, and switch between multiple family member profiles
- **Emergency Medical Cards** - Store critical medical information accessible with one tap
- **Document Upload** - Upload and organize prescriptions, lab reports, and medical scans
- **Medication Tracking** - Schedule medications and mark them as taken
- **SOS Button** - Press-and-hold for 3 seconds to trigger emergency alert (demo mode)
- **Health Chat** - Simple rule-based chatbot for health information

### 🔄 Data Persistence

**Current (MVP):** All data is stored in browser localStorage (client-side only)

This is **intentional for the MVP** as specified in the project brief. The MVP is a client-only application designed for demonstration and learning purposes.

**Important Notes:**
- Data persists in your browser between sessions
- Data will be cleared if you clear browser storage
- Data is NOT synced across devices or browsers
- This is perfect for demos and testing workflows
- NOT suitable for real medical data (no encryption, no backup)

**Next Steps for Production:** See "Future Integrations" section below to migrate to Firebase/Firestore for secure cloud storage and real authentication.

## 🎨 Design Philosophy

Arogya Locker follows healthcare UX best practices:

- **Medical Trust** - Clean, professional aesthetic for reliability
- **Accessibility First** - Large touch targets (minimum 44px), high contrast, clear typography
- **Progressive Disclosure** - Show essential information first, details on demand
- **Gentle Interactions** - Smooth animations, clear feedback, forgiving error handling

## 🏗️ Project Structure

```
/client
  /src
    /components        - Reusable UI components
      /ui             - Shadcn UI components (buttons, cards, dialogs, etc.)
      profile-selector.tsx
      emergency-card-dialog.tsx
      add-profile-dialog.tsx
      sos-button.tsx
    /pages            - Application pages/routes
      login.tsx       - Phone + OTP authentication
      dashboard.tsx   - Main dashboard with quick actions
      medications.tsx - Medication schedule and tracking
      uploads.tsx     - Document upload and management
      profiles.tsx    - Family profile management
      chat.tsx        - Health chatbot interface
    /lib
      storage.ts      - localStorage abstraction (REPLACE with Firestore later)
      api.ts          - API placeholder functions (REPLACE with real backends)
      queryClient.ts  - React Query configuration
      utils.ts        - Utility functions
    App.tsx          - Main app with routing
    index.css        - Tailwind CSS with design tokens
/server
  storage.ts         - In-memory storage interface (can migrate to DB)
  routes.ts          - API routes for all features
  index.ts           - Express server setup
/shared
  schema.ts          - Shared TypeScript types and Zod schemas
/attached_assets
  /generated_images  - AI-generated healthcare images
/docs
  developer-notes.md - Where to add integrations (see below)
```

## 🔧 How to Test Features

### Login Flow
1. Enter any 10-digit phone number
2. Click "Send OTP"
3. Enter any 6-digit code (e.g., 123456)
4. You're in!

### Profile Management
1. After login, create your first profile
2. Add family members using the "+" button
3. Switch between profiles by clicking avatars

### Emergency Card
1. Click "Emergency Card" on dashboard
2. Click the edit icon to add medical information
3. Fill in blood type, allergies, emergency contacts, etc.
4. Click "Save Changes"

### Medications
1. Go to "Medications" section
2. Click "Add Medication"
3. Fill in name, dosage, frequency, time
4. Check off medications as you take them

### Document Upload
1. Go to "Upload" section
2. Click upload button or drag files
3. Select document type (prescription, lab report, etc.)
4. Add notes if needed

### SOS Button
1. Press and hold the red SOS button for 3 seconds
2. See demo emergency alert notification
3. Check browser console for logged event

### Health Chat
1. Go to "Health Chat"
2. Ask health-related questions
3. Try suggested questions for quick demo

## 🔐 Security & Privacy Notes

### ⚠️ Current MVP Limitations

- **Data is stored in browser localStorage** - Not secure for real medical data
- **No encryption** - Data is stored in plain text locally
- **No user authentication** - Demo OTP accepts any code
- **API keys in client code** - Don't add real API keys yet

### ✅ Production Security Recommendations

Before using with real medical data:

1. **Migrate to Firebase/Firestore** - See `docs/developer-notes.md`
2. **Implement real authentication** - Firebase Auth or Twilio OTP
3. **Add encryption** - Encrypt sensitive medical data
4. **Move API calls to backend** - Never expose API keys in frontend
5. **Add HIPAA compliance** - If handling US patient data
6. **Implement proper backup** - Automatic cloud backups

## 🚀 Future Integrations (Placeholder Hooks Included)

All these integrations have placeholder code ready. See `docs/developer-notes.md` for exact file locations.

### 1. Firebase (Authentication & Database)
- **Replace:** `client/src/lib/storage.ts` and `client/src/lib/api.ts`
- **Files:** See auth functions in `api.ts`
- **Replit Integration:** Available - search for "Firebase" in integrations

### 2. Google Vision (OCR for prescriptions)
- **Replace:** `uploadFile()` function in `client/src/lib/api.ts`
- **Add:** Real OCR API call to extract text from images
- **Comment location:** Search for "TODO: Call OCR API here"

### 3. OpenAI / LLM (Intelligent chatbot)
- **Replace:** `getChatbotResponse()` in `client/src/lib/api.ts`
- **Add:** Real LLM API call for intelligent health responses
- **Comment location:** Search for "TODO: Replace with actual LLM call"
- **Replit Integration:** Available - search for "OpenAI" in integrations

### 4. Twilio (SMS/Voice for SOS)
- **Replace:** `sendSos()` in `client/src/lib/api.ts`
- **Add:** Real SMS/voice call to emergency contacts
- **Comment location:** Search for "TODO: Add actual API call here"
- **Replit Integration:** Available - search for "Twilio" in integrations

### 5. n8n (Workflow Automation)
- **Use for:** Medication reminders, appointment alerts, automated backups
- **Integration:** Create webhooks in n8n and call them from the app
- **Example:** Trigger workflows from SOS button, medication schedule

## 🔑 Environment Variables (Replit Secrets)

When adding integrations, use Replit Secrets (never commit API keys to code):

1. Open Replit "Secrets" tab (lock icon on the left)
2. Add your API keys:
   - `FIREBASE_API_KEY`
   - `GOOGLE_VISION_API_KEY`
   - `OPENAI_API_KEY`
   - `TWILIO_ACCOUNT_SID`
   - `TWILIO_AUTH_TOKEN`
   - `TWILIO_PHONE_NUMBER`

3. Access them in code:
   ```javascript
   // Frontend (must prefix with VITE_)
   const apiKey = import.meta.env.VITE_FIREBASE_API_KEY;

   // Backend
   const apiKey = process.env.FIREBASE_API_KEY;
   ```

## 📚 Technology Stack

- **Frontend:** React 18, TypeScript, Tailwind CSS, Shadcn UI
- **Routing:** Wouter (lightweight React router)
- **State:** React Query (TanStack Query v5)
- **Forms:** React Hook Form + Zod validation
- **Backend:** Express.js (minimal API layer)
- **Storage (MVP):** localStorage (client-side)
- **Storage (Future):** Firebase Firestore or PostgreSQL
- **Build Tool:** Vite

## 🎓 Learning Resources

This project is designed to be beginner-friendly. Check out:

- `docs/quick-tutorial.md` - Plain English explanation of how the app works
- `docs/developer-notes.md` - Where to add each integration
- **Comments in code** - Look for "TODO:" comments showing where to add features

## 🐛 Known Issues & Limitations

- SOS button currently only logs to console (add Twilio integration for real alerts)
- Chatbot uses simple rules (add OpenAI for intelligent responses)
- OCR not implemented (add Google Vision integration)
- Data is not backed up (add Firebase for cloud storage)
- No real-time sync between devices (add Firebase for multi-device support)

## 📞 Support

For medical emergencies, always call your local emergency services. This app is for information management only.

For technical questions about this code, check the inline comments or `docs/` folder.

## 📄 License

This project is for educational and demonstration purposes. Consult legal/medical compliance experts before deploying for real patient data.

---

**Built with ❤️ for families managing their health together**
