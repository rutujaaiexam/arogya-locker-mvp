import { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { storage } from '@/lib/storage';
import { UserPlus } from 'lucide-react';

interface AddProfileDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onProfileAdded: () => void;
}

const AVATAR_COLORS = [
  '#3B82F6', // blue
  '#10B981', // green
  '#F59E0B', // amber
  '#EF4444', // red
  '#8B5CF6', // purple
  '#EC4899', // pink
  '#14B8A6', // teal
  '#F97316', // orange
];

const RELATIONS = [
  'Self',
  'Spouse',
  'Mother',
  'Father',
  'Son',
  'Daughter',
  'Brother',
  'Sister',
  'Grandmother',
  'Grandfather',
  'Other',
];

export function AddProfileDialog({ open, onOpenChange, onProfileAdded }: AddProfileDialogProps) {
  const { toast } = useToast();
  const [name, setName] = useState('');
  const [relation, setRelation] = useState('');
  const [dateOfBirth, setDateOfBirth] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!name.trim()) {
      toast({
        title: 'Name required',
        description: 'Please enter a name for this profile',
        variant: 'destructive',
      });
      return;
    }

    setLoading(true);
    
    try {
      const user = storage.getUser();
      const profiles = storage.getProfiles();
      const isPrimary = profiles.length === 0;
      
      const newProfile = {
        id: crypto.randomUUID(),
        userId: user?.id || 'demo-user',
        name: name.trim(),
        relation: relation || undefined,
        dateOfBirth: dateOfBirth || undefined,
        bloodType: undefined,
        allergies: [],
        emergencyContact: undefined,
        emergencyContactPhone: undefined,
        chronicConditions: [],
        currentMedications: undefined,
        avatarColor: AVATAR_COLORS[profiles.length % AVATAR_COLORS.length],
        isPrimary,
      };

      storage.setProfiles([...profiles, newProfile]);
      
      toast({
        title: 'Profile created!',
        description: `${name}'s health profile has been set up`,
      });

      setName('');
      setRelation('');
      setDateOfBirth('');
      onProfileAdded();
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to create profile. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent data-testid="dialog-add-profile">
        <DialogHeader>
          <DialogTitle className="text-2xl flex items-center gap-2">
            <UserPlus className="w-6 h-6" />
            Add Family Member
          </DialogTitle>
          <DialogDescription className="text-base">
            Create a health profile for a family member
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="name" className="text-lg font-medium">Full Name *</Label>
            <Input
              id="name"
              data-testid="input-profile-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Enter full name"
              className="h-14 text-lg"
              disabled={loading}
              autoFocus
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="relation" className="text-lg font-medium">Relationship</Label>
            <Select value={relation} onValueChange={setRelation} disabled={loading}>
              <SelectTrigger id="relation" data-testid="select-relation" className="h-14 text-lg">
                <SelectValue placeholder="Select relationship" />
              </SelectTrigger>
              <SelectContent>
                {RELATIONS.map(rel => (
                  <SelectItem key={rel} value={rel}>{rel}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="dob" className="text-lg font-medium">Date of Birth</Label>
            <Input
              id="dob"
              data-testid="input-date-of-birth"
              type="date"
              value={dateOfBirth}
              onChange={(e) => setDateOfBirth(e.target.value)}
              className="h-14 text-lg"
              disabled={loading}
            />
          </div>

          <Button
            type="submit"
            data-testid="button-create-profile"
            className="w-full h-14 text-lg font-semibold"
            disabled={loading || !name.trim()}
          >
            {loading ? 'Creating...' : 'Create Profile'}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
