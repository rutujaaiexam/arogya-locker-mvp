import { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { storage } from '@/lib/storage';
import { Shield, Edit2, Save, X, Phone } from 'lucide-react';
import type { Profile } from '@shared/schema';

interface EmergencyCardDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  profile: Profile;
  onUpdate: () => void;
}

export function EmergencyCardDialog({ open, onOpenChange, profile, onUpdate }: EmergencyCardDialogProps) {
  const { toast } = useToast();
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    bloodType: profile.bloodType || '',
    allergies: profile.allergies?.join(', ') || '',
    emergencyContact: profile.emergencyContact || '',
    emergencyContactPhone: profile.emergencyContactPhone || '',
    chronicConditions: profile.chronicConditions?.join(', ') || '',
    currentMedications: profile.currentMedications || '',
  });

  const handleSave = () => {
    const profiles = storage.getProfiles();
    const updatedProfiles = profiles.map(p => {
      if (p.id === profile.id) {
        return {
          ...p,
          bloodType: formData.bloodType,
          allergies: formData.allergies.split(',').map(a => a.trim()).filter(Boolean),
          emergencyContact: formData.emergencyContact,
          emergencyContactPhone: formData.emergencyContactPhone,
          chronicConditions: formData.chronicConditions.split(',').map(c => c.trim()).filter(Boolean),
          currentMedications: formData.currentMedications,
        };
      }
      return p;
    });

    storage.setProfiles(updatedProfiles);
    onUpdate();
    setIsEditing(false);
    toast({
      title: 'Emergency card updated',
      description: 'Your medical information has been saved',
    });
  };

  const handleCancel = () => {
    setFormData({
      bloodType: profile.bloodType || '',
      allergies: profile.allergies?.join(', ') || '',
      emergencyContact: profile.emergencyContact || '',
      emergencyContactPhone: profile.emergencyContactPhone || '',
      chronicConditions: profile.chronicConditions?.join(', ') || '',
      currentMedications: profile.currentMedications || '',
    });
    setIsEditing(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto" data-testid="dialog-emergency-card">
        <DialogHeader>
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <Shield className="w-8 h-8 text-destructive" />
              <div>
                <DialogTitle className="text-2xl">Emergency Medical Card</DialogTitle>
                <DialogDescription className="text-base">
                  {profile.name} • Critical medical information
                </DialogDescription>
              </div>
            </div>
            {!isEditing && (
              <Button
                data-testid="button-edit-emergency-card"
                variant="outline"
                size="icon"
                onClick={() => setIsEditing(true)}
              >
                <Edit2 className="w-4 h-4" />
              </Button>
            )}
          </div>
        </DialogHeader>

        {isEditing ? (
          <div className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="bloodType" className="text-lg font-medium">Blood Type</Label>
              <Input
                id="bloodType"
                data-testid="input-blood-type"
                value={formData.bloodType}
                onChange={(e) => setFormData({ ...formData, bloodType: e.target.value })}
                placeholder="e.g., O+, A-, B+"
                className="h-14 text-lg"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="allergies" className="text-lg font-medium">Allergies</Label>
              <Textarea
                id="allergies"
                data-testid="input-allergies"
                value={formData.allergies}
                onChange={(e) => setFormData({ ...formData, allergies: e.target.value })}
                placeholder="Separate with commas: e.g., Penicillin, Peanuts, Latex"
                className="min-h-20 text-base"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="chronicConditions" className="text-lg font-medium">Chronic Conditions</Label>
              <Textarea
                id="chronicConditions"
                data-testid="input-chronic-conditions"
                value={formData.chronicConditions}
                onChange={(e) => setFormData({ ...formData, chronicConditions: e.target.value })}
                placeholder="Separate with commas: e.g., Diabetes, Hypertension, Asthma"
                className="min-h-20 text-base"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="currentMedications" className="text-lg font-medium">Current Medications</Label>
              <Textarea
                id="currentMedications"
                data-testid="input-current-medications"
                value={formData.currentMedications}
                onChange={(e) => setFormData({ ...formData, currentMedications: e.target.value })}
                placeholder="List current medications and dosages"
                className="min-h-24 text-base"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="emergencyContact" className="text-lg font-medium">Emergency Contact Name</Label>
              <Input
                id="emergencyContact"
                data-testid="input-emergency-contact"
                value={formData.emergencyContact}
                onChange={(e) => setFormData({ ...formData, emergencyContact: e.target.value })}
                placeholder="Full name"
                className="h-14 text-lg"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="emergencyContactPhone" className="text-lg font-medium">Emergency Contact Phone</Label>
              <Input
                id="emergencyContactPhone"
                data-testid="input-emergency-contact-phone"
                type="tel"
                value={formData.emergencyContactPhone}
                onChange={(e) => setFormData({ ...formData, emergencyContactPhone: e.target.value })}
                placeholder="Phone number"
                className="h-14 text-lg"
              />
            </div>

            <div className="flex gap-3">
              <Button
                data-testid="button-save-emergency-card"
                onClick={handleSave}
                className="flex-1 h-14 text-lg gap-2"
              >
                <Save className="w-5 h-5" />
                Save Changes
              </Button>
              <Button
                data-testid="button-cancel-edit"
                variant="outline"
                onClick={handleCancel}
                className="flex-1 h-14 text-lg gap-2"
              >
                <X className="w-5 h-5" />
                Cancel
              </Button>
            </div>
          </div>
        ) : (
          <div className="space-y-6">
            {/* View Mode - Large, Clear Display */}
            <div className="bg-destructive/10 border-2 border-destructive/20 rounded-xl p-6 space-y-4">
              <div className="flex items-center gap-2 text-destructive font-semibold text-lg">
                <Shield className="w-6 h-6" />
                <span>EMERGENCY INFORMATION</span>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-lg">
                <div>
                  <p className="text-sm font-medium text-muted-foreground mb-1">Name</p>
                  <p className="font-semibold text-xl">{profile.name}</p>
                </div>
                {profile.dateOfBirth && (
                  <div>
                    <p className="text-sm font-medium text-muted-foreground mb-1">Date of Birth</p>
                    <p className="font-semibold text-xl">{profile.dateOfBirth}</p>
                  </div>
                )}
                {formData.bloodType && (
                  <div>
                    <p className="text-sm font-medium text-muted-foreground mb-1">Blood Type</p>
                    <Badge variant="destructive" className="text-lg px-4 py-1">{formData.bloodType}</Badge>
                  </div>
                )}
              </div>
            </div>

            {formData.allergies && (
              <div className="space-y-2">
                <h3 className="text-lg font-semibold text-destructive">⚠️ Allergies</h3>
                <div className="flex flex-wrap gap-2">
                  {formData.allergies.split(',').map((allergy, i) => (
                    <Badge key={i} variant="destructive" className="text-base px-3 py-1">
                      {allergy.trim()}
                    </Badge>
                  ))}
                </div>
              </div>
            )}

            {formData.chronicConditions && (
              <div className="space-y-2">
                <h3 className="text-lg font-semibold">Medical Conditions</h3>
                <div className="flex flex-wrap gap-2">
                  {formData.chronicConditions.split(',').map((condition, i) => (
                    <Badge key={i} variant="secondary" className="text-base px-3 py-1">
                      {condition.trim()}
                    </Badge>
                  ))}
                </div>
              </div>
            )}

            {formData.currentMedications && (
              <div className="space-y-2">
                <h3 className="text-lg font-semibold">Current Medications</h3>
                <p className="text-base whitespace-pre-wrap">{formData.currentMedications}</p>
              </div>
            )}

            {(formData.emergencyContact || formData.emergencyContactPhone) && (
              <div className="bg-primary/10 border border-primary/20 rounded-xl p-6 space-y-3">
                <h3 className="text-lg font-semibold flex items-center gap-2">
                  <Phone className="w-5 h-5" />
                  Emergency Contact
                </h3>
                {formData.emergencyContact && (
                  <p className="text-lg font-medium">{formData.emergencyContact}</p>
                )}
                {formData.emergencyContactPhone && (
                  <p className="text-2xl font-bold text-primary">{formData.emergencyContactPhone}</p>
                )}
              </div>
            )}

            <p className="text-sm text-muted-foreground text-center pt-4">
              This card is designed for first responders and medical professionals
            </p>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
