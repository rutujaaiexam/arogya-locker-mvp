import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Plus } from 'lucide-react';
import type { Profile } from '@shared/schema';

interface ProfileSelectorProps {
  profiles: Profile[];
  currentProfileId: string | null;
  onSelectProfile: (profileId: string) => void;
  onAddProfile: () => void;
}

export function ProfileSelector({ profiles, currentProfileId, onSelectProfile, onAddProfile }: ProfileSelectorProps) {
  return (
    <div className="flex items-center gap-4 overflow-x-auto pb-2">
      {profiles.map((profile) => {
        const isActive = profile.id === currentProfileId;
        const initials = profile.name
          .split(' ')
          .map(n => n[0])
          .join('')
          .toUpperCase()
          .slice(0, 2);

        return (
          <button
            key={profile.id}
            data-testid={`button-profile-${profile.id}`}
            onClick={() => onSelectProfile(profile.id)}
            className="flex flex-col items-center gap-2 min-w-fit group"
          >
            <div className={`relative ${isActive ? 'ring-4 ring-primary ring-offset-4 ring-offset-background rounded-full' : ''}`}>
              <Avatar className="w-20 h-20 hover-elevate transition-all">
                <AvatarFallback 
                  className="text-xl font-semibold"
                  style={{ backgroundColor: profile.avatarColor }}
                >
                  {initials}
                </AvatarFallback>
              </Avatar>
            </div>
            <span className={`text-sm font-medium ${isActive ? 'text-foreground' : 'text-muted-foreground'} group-hover:text-foreground transition-colors`}>
              {profile.name}
            </span>
            {profile.relation && (
              <span className="text-xs text-muted-foreground">
                {profile.relation}
              </span>
            )}
          </button>
        );
      })}
      
      {/* Add Profile Button */}
      <button
        data-testid="button-add-profile"
        onClick={onAddProfile}
        className="flex flex-col items-center gap-2 min-w-fit group"
      >
        <div className="w-20 h-20 rounded-full border-2 border-dashed border-muted-foreground/50 hover:border-primary hover:bg-accent flex items-center justify-center transition-all hover-elevate">
          <Plus className="w-8 h-8 text-muted-foreground group-hover:text-primary transition-colors" />
        </div>
        <span className="text-sm font-medium text-muted-foreground group-hover:text-foreground transition-colors">
          Add Profile
        </span>
      </button>
    </div>
  );
}
