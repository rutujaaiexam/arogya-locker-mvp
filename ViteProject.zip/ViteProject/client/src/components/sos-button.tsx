import { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { sendSos } from '@/lib/api';
import { storage } from '@/lib/storage';
import { Phone, AlertCircle } from 'lucide-react';

interface SosButtonProps {
  profileId: string | null;
}

export function SosButton({ profileId }: SosButtonProps) {
  const { toast } = useToast();
  const [isPressed, setIsPressed] = useState(false);
  const [progress, setProgress] = useState(0);
  const timeoutRef = useRef<NodeJS.Timeout>();
  const intervalRef = useRef<NodeJS.Timeout>();

  useEffect(() => {
    return () => {
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, []);

  const handlePressStart = () => {
    if (!profileId) {
      toast({
        title: 'No profile selected',
        description: 'Please select a profile first',
        variant: 'destructive',
      });
      return;
    }

    setIsPressed(true);
    setProgress(0);

    // Animate progress over 3 seconds
    const startTime = Date.now();
    const duration = 3000;

    intervalRef.current = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const newProgress = Math.min((elapsed / duration) * 100, 100);
      setProgress(newProgress);
    }, 50);

    // Trigger SOS after 3 seconds
    timeoutRef.current = setTimeout(async () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
      
      setProgress(100);
      await triggerSos();
      
      // Reset after a delay
      setTimeout(() => {
        setIsPressed(false);
        setProgress(0);
      }, 1000);
    }, duration);
  };

  const handlePressEnd = () => {
    if (timeoutRef.current) clearTimeout(timeoutRef.current);
    if (intervalRef.current) clearInterval(intervalRef.current);
    
    if (progress < 100) {
      setIsPressed(false);
      setProgress(0);
    }
  };

  const triggerSos = async () => {
    try {
      const result = await sendSos(profileId!, 'Location unavailable');
      
      // Log SOS event
      const sosEvents = storage.getSosEvents();
      const newEvent = {
        id: result.eventId,
        profileId: profileId!,
        triggeredAt: new Date().toISOString(),
        location: 'Location unavailable',
        notes: 'SOS activated from app',
      };
      storage.setSosEvents([...sosEvents, newEvent]);

      toast({
        title: '🚨 SOS Activated',
        description: 'Emergency contacts have been notified (demo mode)',
        variant: 'destructive',
      });
    } catch (error) {
      toast({
        title: 'SOS Failed',
        description: 'Could not send emergency alert. Please call emergency services directly.',
        variant: 'destructive',
      });
    }
  };

  if (!profileId) return null;

  return (
    <div className="fixed bottom-8 right-8 z-50">
      <div className="relative">
        <button
          data-testid="button-sos"
          onMouseDown={handlePressStart}
          onMouseUp={handlePressEnd}
          onMouseLeave={handlePressEnd}
          onTouchStart={handlePressStart}
          onTouchEnd={handlePressEnd}
          className={`
            w-24 h-24 rounded-full bg-gradient-to-br from-destructive to-destructive/80
            text-destructive-foreground shadow-2xl
            flex flex-col items-center justify-center gap-1
            transition-all duration-200
            hover:scale-105 active:scale-95
            ${isPressed ? 'ring-4 ring-destructive ring-offset-4 ring-offset-background animate-pulse' : ''}
          `}
          style={{
            background: isPressed 
              ? `conic-gradient(hsl(var(--destructive)) ${progress}%, transparent ${progress}%)`
              : undefined,
          }}
        >
          <Phone className="w-10 h-10" />
          <span className="text-sm font-bold">SOS</span>
        </button>

        {!isPressed && (
          <div className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-destructive animate-ping" />
        )}
      </div>

      {isPressed && progress < 100 && (
        <p className="absolute -top-12 left-1/2 -translate-x-1/2 whitespace-nowrap bg-destructive text-destructive-foreground px-4 py-2 rounded-lg text-sm font-semibold">
          Hold for {Math.ceil((100 - progress) / 33)}s...
        </p>
      )}
    </div>
  );
}
