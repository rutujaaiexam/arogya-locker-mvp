// API abstraction layer - placeholder functions for future backend integration
// In MVP: Returns mock data and simulates API calls with localStorage
// In production: Replace these with actual HTTP calls to your backend/n8n/Firebase

import type { Profile, Medication, Upload, SosEvent, ChatMessage } from '@shared/schema';

// ============================================================
// AUTHENTICATION API
// ============================================================
// TODO: Replace with Firebase Auth or Twilio phone authentication
export async function loginPhone(phone: string): Promise<{ success: boolean; message: string }> {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 500));
  
  // Mock: Always succeed for demo
  return {
    success: true,
    message: 'OTP sent successfully (demo mode)',
  };
}

export async function verifyOtp(phone: string, otp: string): Promise<{ success: boolean; userId?: string; message: string }> {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 500));
  
  // Mock: Accept any 6-digit OTP for demo
  if (otp.length === 6) {
    return {
      success: true,
      userId: 'demo-user-' + phone.slice(-4),
      message: 'Login successful',
    };
  }
  
  return {
    success: false,
    message: 'Invalid OTP',
  };
}

// ============================================================
// SOS API
// ============================================================
// TODO: Replace with actual webhook call to Twilio/n8n for emergency alerts
export async function sendSos(profileId: string, location?: string): Promise<{ success: boolean; eventId: string }> {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 800));
  
  console.log('[SOS TRIGGERED]', {
    profileId,
    location: location || 'Location unavailable',
    timestamp: new Date().toISOString(),
  });
  
  // TODO: Add actual API call here
  // Example: await fetch('https://your-n8n-webhook.com/sos', { method: 'POST', body: JSON.stringify({ profileId, location }) })
  
  return {
    success: true,
    eventId: crypto.randomUUID(),
  };
}

// ============================================================
// UPLOAD/OCR API
// ============================================================
// TODO: Replace with Google Vision API or n8n OCR workflow
export async function uploadFile(file: File): Promise<{ 
  success: boolean; 
  fileData: string; 
  extractedText?: string;
  message: string;
}> {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  return new Promise((resolve) => {
    const reader = new FileReader();
    
    reader.onload = () => {
      const base64 = reader.result as string;
      
      // TODO: Call OCR API here
      // Example: const ocrResult = await fetch('https://vision.googleapis.com/v1/images:annotate', { ... })
      
      resolve({
        success: true,
        fileData: base64,
        extractedText: undefined, // Will be populated by OCR in production
        message: 'File uploaded successfully (OCR pending)',
      });
    };
    
    reader.onerror = () => {
      resolve({
        success: false,
        fileData: '',
        message: 'File upload failed',
      });
    };
    
    reader.readAsDataURL(file);
  });
}

// ============================================================
// CHATBOT API
// ============================================================
// TODO: Replace with OpenAI/LLM integration for intelligent responses
export async function getChatbotResponse(message: string, profileContext?: Profile): Promise<string> {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 600));
  
  const lowerMessage = message.toLowerCase();
  
  // Simple rule-based responses for MVP demo
  // TODO: Replace with actual LLM call
  // Example: const response = await openai.chat.completions.create({ messages: [...] })
  
  if (lowerMessage.includes('hello') || lowerMessage.includes('hi')) {
    return "Hello! I'm here to help with your health questions. Please remember, I provide general information only and cannot replace professional medical advice.";
  }
  
  if (lowerMessage.includes('medicine') || lowerMessage.includes('medication')) {
    return "I can help you understand medication information. For specific dosing questions, please consult your doctor or pharmacist. Would you like to set a medication reminder?";
  }
  
  if (lowerMessage.includes('allergy') || lowerMessage.includes('allergies')) {
    return "Allergies are important to track. Make sure your emergency card is up to date with all known allergies. If you're experiencing an allergic reaction, please seek immediate medical attention.";
  }
  
  if (lowerMessage.includes('emergency') || lowerMessage.includes('help')) {
    return "For medical emergencies, please call emergency services immediately or use the SOS button in the app. I'm here for general health information only.";
  }
  
  if (lowerMessage.includes('thank')) {
    return "You're welcome! Stay healthy and remember to keep your medical information updated.";
  }
  
  // Default response
  return "I'm here to provide general health information. For specific medical advice, please consult with a healthcare professional. How else can I assist you today?";
}
