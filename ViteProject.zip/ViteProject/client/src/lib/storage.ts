// LocalStorage abstraction layer for demo MVP
// This will be replaced with Firebase/Firestore in production
// See docs/developer-notes.md for migration instructions

const STORAGE_KEYS = {
  USER: 'arogya_user',
  PROFILES: 'arogya_profiles',
  MEDICATIONS: 'arogya_medications',
  MEDICATION_LOGS: 'arogya_medication_logs',
  UPLOADS: 'arogya_uploads',
  SOS_EVENTS: 'arogya_sos_events',
  CHAT_MESSAGES: 'arogya_chat_messages',
} as const;

export const storage = {
  // Generic get/set for any data
  get<T>(key: string): T | null {
    try {
      const item = localStorage.getItem(key);
      return item ? JSON.parse(item) : null;
    } catch (error) {
      console.error('Storage get error:', error);
      return null;
    }
  },

  set<T>(key: string, value: T): void {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch (error) {
      console.error('Storage set error:', error);
    }
  },

  remove(key: string): void {
    try {
      localStorage.removeItem(key);
    } catch (error) {
      console.error('Storage remove error:', error);
    }
  },

  clear(): void {
    try {
      // Only clear Arogya-specific keys
      Object.values(STORAGE_KEYS).forEach(key => {
        localStorage.removeItem(key);
      });
    } catch (error) {
      console.error('Storage clear error:', error);
    }
  },

  // Typed accessors for specific data types
  getUser() {
    return this.get(STORAGE_KEYS.USER);
  },

  setUser(user: any) {
    this.set(STORAGE_KEYS.USER, user);
  },

  getProfiles() {
    return this.get(STORAGE_KEYS.PROFILES) || [];
  },

  setProfiles(profiles: any[]) {
    this.set(STORAGE_KEYS.PROFILES, profiles);
  },

  getMedications() {
    return this.get(STORAGE_KEYS.MEDICATIONS) || [];
  },

  setMedications(medications: any[]) {
    this.set(STORAGE_KEYS.MEDICATIONS, medications);
  },

  getMedicationLogs() {
    return this.get(STORAGE_KEYS.MEDICATION_LOGS) || [];
  },

  setMedicationLogs(logs: any[]) {
    this.set(STORAGE_KEYS.MEDICATION_LOGS, logs);
  },

  getUploads() {
    return this.get(STORAGE_KEYS.UPLOADS) || [];
  },

  setUploads(uploads: any[]) {
    this.set(STORAGE_KEYS.UPLOADS, uploads);
  },

  getSosEvents() {
    return this.get(STORAGE_KEYS.SOS_EVENTS) || [];
  },

  setSosEvents(events: any[]) {
    this.set(STORAGE_KEYS.SOS_EVENTS, events);
  },

  getChatMessages() {
    return this.get(STORAGE_KEYS.CHAT_MESSAGES) || [];
  },

  setChatMessages(messages: any[]) {
    this.set(STORAGE_KEYS.CHAT_MESSAGES, messages);
  },
};
