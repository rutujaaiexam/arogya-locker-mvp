import { useState, useEffect, useRef } from 'react';
import { useLocation } from 'wouter';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { useToast } from '@/hooks/use-toast';
import { storage } from '@/lib/storage';
import { getChatbotResponse } from '@/lib/api';
import { ArrowLeft, Send, MessageCircle, Bot, User } from 'lucide-react';
import type { ChatMessage, Profile } from '@shared/schema';

const SUGGESTED_QUESTIONS = [
  'How do I manage my medications?',
  'What should I do in an emergency?',
  'Tell me about allergy management',
  'How do I update my emergency card?',
];

export default function Chat() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [currentProfileId, setCurrentProfileId] = useState<string | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const user = storage.getUser();
    if (!user) {
      setLocation('/');
      return;
    }

    loadData();
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const loadData = () => {
    const loadedProfiles = storage.getProfiles();
    const loadedMessages = storage.getChatMessages();

    setProfiles(loadedProfiles);
    setMessages(loadedMessages);

    if (loadedProfiles.length > 0 && !currentProfileId) {
      const primaryProfile = loadedProfiles.find(p => p.isPrimary) || loadedProfiles[0];
      setCurrentProfileId(primaryProfile.id);
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSendMessage = async (messageText?: string) => {
    const textToSend = messageText || input.trim();
    if (!textToSend || !currentProfileId) return;

    const userMessage: ChatMessage = {
      id: crypto.randomUUID(),
      profileId: currentProfileId,
      message: textToSend,
      isBot: false,
      timestamp: new Date().toISOString(),
    };

    const updatedMessages = [...messages, userMessage];
    setMessages(updatedMessages);
    storage.setChatMessages(updatedMessages);
    setInput('');
    setLoading(true);

    try {
      const currentProfile = profiles.find(p => p.id === currentProfileId);
      const botResponse = await getChatbotResponse(textToSend, currentProfile);

      const botMessage: ChatMessage = {
        id: crypto.randomUUID(),
        profileId: currentProfileId,
        message: botResponse,
        isBot: true,
        timestamp: new Date().toISOString(),
      };

      const finalMessages = [...updatedMessages, botMessage];
      setMessages(finalMessages);
      storage.setChatMessages(finalMessages);
    } catch (error) {
      toast({
        title: 'Chat error',
        description: 'Failed to get response. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
      inputRef.current?.focus();
    }
  };

  const handleSuggestedQuestion = (question: string) => {
    handleSendMessage(question);
  };

  const currentProfile = profiles.find(p => p.id === currentProfileId);
  const profileMessages = messages.filter(m => m.profileId === currentProfileId);

  if (!currentProfile) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  }

  return (
    <div className="h-screen flex flex-col bg-background">
      {/* Header */}
      <header className="border-b bg-card z-10">
        <div className="max-w-6xl mx-auto px-4 md:px-8 py-4 flex items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <Button
              data-testid="button-back"
              variant="ghost"
              size="icon"
              onClick={() => setLocation('/dashboard')}
            >
              <ArrowLeft className="w-6 h-6" />
            </Button>
            <div className="flex items-center gap-3">
              <MessageCircle className="w-6 h-6 text-primary" />
              <div>
                <h1 className="text-2xl md:text-3xl font-semibold">Health Assistant</h1>
                <p className="text-sm text-muted-foreground">{currentProfile.name}</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Disclaimer */}
      <div className="bg-muted/50 border-b">
        <div className="max-w-4xl mx-auto px-4 md:px-8 py-3">
          <p className="text-sm text-muted-foreground text-center">
            ⚠️ This chatbot provides general health information only and cannot replace professional medical advice.
            For medical emergencies, call emergency services or use the SOS button.
          </p>
        </div>
      </div>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto">
        <div className="max-w-4xl mx-auto px-4 md:px-8 py-8 space-y-6">
          {profileMessages.length === 0 ? (
            <div className="text-center space-y-6 pt-12">
              <div className="w-20 h-20 mx-auto rounded-full bg-primary/10 flex items-center justify-center">
                <Bot className="w-10 h-10 text-primary" />
              </div>
              <div>
                <h2 className="text-2xl font-semibold mb-2">Hello, {currentProfile.name}!</h2>
                <p className="text-lg text-muted-foreground mb-8">
                  I'm your health assistant. Ask me anything about managing your health information.
                </p>
              </div>
              
              <div className="space-y-3">
                <p className="text-base font-medium">Try asking:</p>
                <div className="flex flex-wrap gap-3 justify-center">
                  {SUGGESTED_QUESTIONS.map((question, i) => (
                    <Button
                      key={i}
                      data-testid={`button-suggestion-${i}`}
                      variant="outline"
                      onClick={() => handleSuggestedQuestion(question)}
                      className="text-sm"
                    >
                      {question}
                    </Button>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <>
              {profileMessages.map((msg, index) => (
                <div
                  key={msg.id}
                  data-testid={`message-${index}`}
                  className={`flex gap-4 ${msg.isBot ? 'justify-start' : 'justify-end'}`}
                >
                  {msg.isBot && (
                    <Avatar className="w-10 h-10 flex-shrink-0">
                      <AvatarFallback className="bg-primary/10">
                        <Bot className="w-5 h-5 text-primary" />
                      </AvatarFallback>
                    </Avatar>
                  )}
                  
                  <div className={`flex-1 max-w-2xl ${msg.isBot ? '' : 'flex justify-end'}`}>
                    <Card className={`${msg.isBot ? 'bg-card' : 'bg-primary text-primary-foreground'}`}>
                      <CardContent className="p-4">
                        <p className="text-base whitespace-pre-wrap">{msg.message}</p>
                        <p className={`text-xs mt-2 ${msg.isBot ? 'text-muted-foreground' : 'text-primary-foreground/70'}`}>
                          {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </p>
                      </CardContent>
                    </Card>
                  </div>

                  {!msg.isBot && (
                    <Avatar className="w-10 h-10 flex-shrink-0">
                      <AvatarFallback style={{ backgroundColor: currentProfile.avatarColor }}>
                        <User className="w-5 h-5" />
                      </AvatarFallback>
                    </Avatar>
                  )}
                </div>
              ))}

              {loading && (
                <div className="flex gap-4 justify-start">
                  <Avatar className="w-10 h-10 flex-shrink-0">
                    <AvatarFallback className="bg-primary/10">
                      <Bot className="w-5 h-5 text-primary" />
                    </AvatarFallback>
                  </Avatar>
                  <Card className="bg-card">
                    <CardContent className="p-4">
                      <div className="flex gap-2">
                        <div className="w-2 h-2 rounded-full bg-muted-foreground animate-bounce" style={{ animationDelay: '0ms' }} />
                        <div className="w-2 h-2 rounded-full bg-muted-foreground animate-bounce" style={{ animationDelay: '150ms' }} />
                        <div className="w-2 h-2 rounded-full bg-muted-foreground animate-bounce" style={{ animationDelay: '300ms' }} />
                      </div>
                    </CardContent>
                  </Card>
                </div>
              )}

              <div ref={messagesEndRef} />
            </>
          )}
        </div>
      </div>

      {/* Input Area */}
      <div className="border-t bg-card">
        <div className="max-w-4xl mx-auto px-4 md:px-8 py-4">
          {profileMessages.length === 0 && (
            <div className="mb-4 flex flex-wrap gap-2">
              {SUGGESTED_QUESTIONS.slice(0, 2).map((question, i) => (
                <Badge
                  key={i}
                  variant="secondary"
                  className="cursor-pointer hover-elevate text-sm px-3 py-1"
                  onClick={() => handleSuggestedQuestion(question)}
                  data-testid={`badge-suggestion-${i}`}
                >
                  {question}
                </Badge>
              ))}
            </div>
          )}
          
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="flex gap-3"
          >
            <Input
              ref={inputRef}
              data-testid="input-message"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask a health question..."
              className="h-14 text-lg flex-1"
              disabled={loading}
            />
            <Button
              type="submit"
              data-testid="button-send"
              size="icon"
              className="h-14 w-14 flex-shrink-0"
              disabled={!input.trim() || loading}
            >
              <Send className="w-5 h-5" />
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
}
