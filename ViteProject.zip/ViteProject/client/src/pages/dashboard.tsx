import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { storage } from '@/lib/storage';
import { ProfileSelector } from '@/components/profile-selector';
import { EmergencyCardDialog } from '@/components/emergency-card-dialog';
import { AddProfileDialog } from '@/components/add-profile-dialog';
import { SosButton } from '@/components/sos-button';
import { 
  Shield, 
  Pill, 
  FileText, 
  MessageCircle, 
  Calendar,
  Upload,
  LogOut,
  CheckCircle2,
  Clock
} from 'lucide-react';
import type { Profile, Medication, Upload as UploadType } from '@shared/schema';

export default function Dashboard() {
  const [, setLocation] = useLocation();
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [currentProfileId, setCurrentProfileId] = useState<string | null>(null);
  const [medications, setMedications] = useState<Medication[]>([]);
  const [uploads, setUploads] = useState<UploadType[]>([]);
  const [showEmergencyCard, setShowEmergencyCard] = useState(false);
  const [showAddProfile, setShowAddProfile] = useState(false);
  const [medicationLogs, setMedicationLogs] = useState<any[]>([]);

  useEffect(() => {
    const user = storage.getUser();
    if (!user) {
      setLocation('/');
      return;
    }

    loadData();
  }, []);

  const loadData = () => {
    const loadedProfiles = storage.getProfiles();
    const loadedMeds = storage.getMedications();
    const loadedUploads = storage.getUploads();
    const loadedLogs = storage.getMedicationLogs();

    setProfiles(loadedProfiles);
    setMedications(loadedMeds);
    setUploads(loadedUploads);
    setMedicationLogs(loadedLogs);

    if (loadedProfiles.length > 0 && !currentProfileId) {
      const primaryProfile = loadedProfiles.find(p => p.isPrimary) || loadedProfiles[0];
      setCurrentProfileId(primaryProfile.id);
    }
  };

  const currentProfile = profiles.find(p => p.id === currentProfileId);
  const currentProfileMeds = medications.filter(m => m.profileId === currentProfileId && m.isActive);
  const currentProfileUploads = uploads.filter(u => u.profileId === currentProfileId);

  const todayMeds = currentProfileMeds.filter(med => {
    const today = new Date().toISOString().split('T')[0];
    const takenToday = medicationLogs.some(
      log => log.medicationId === med.id && log.date === today
    );
    return !takenToday;
  });

  const handleLogout = () => {
    storage.clear();
    setLocation('/');
  };

  const handleProfileAdded = () => {
    loadData();
    setShowAddProfile(false);
  };

  if (profiles.length === 0) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4 bg-background">
        <Card className="max-w-md w-full">
          <CardHeader>
            <CardTitle className="text-2xl">Welcome to Arogya Locker!</CardTitle>
            <CardDescription className="text-lg">
              Let's create your first health profile to get started.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <AddProfileDialog
              open={true}
              onOpenChange={() => {}}
              onProfileAdded={handleProfileAdded}
            />
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b bg-card">
        <div className="max-w-6xl mx-auto px-4 md:px-8 py-4 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <Shield className="w-8 h-8 text-primary" />
            <h1 className="text-2xl md:text-3xl font-semibold">Arogya Locker</h1>
          </div>
          <Button
            data-testid="button-logout"
            variant="outline"
            onClick={handleLogout}
            className="gap-2"
          >
            <LogOut className="w-4 h-4" />
            <span className="hidden sm:inline">Logout</span>
          </Button>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 md:px-8 py-8 space-y-8">
        {/* Profile Selector */}
        <section>
          <h2 className="text-xl font-semibold mb-4">Family Profiles</h2>
          <ProfileSelector
            profiles={profiles}
            currentProfileId={currentProfileId}
            onSelectProfile={setCurrentProfileId}
            onAddProfile={() => setShowAddProfile(true)}
          />
        </section>

        {currentProfile && (
          <>
            {/* Quick Actions Grid */}
            <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {/* Emergency Card */}
              <Card className="hover-elevate cursor-pointer transition-all" onClick={() => setShowEmergencyCard(true)} data-testid="card-emergency">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
                  <CardTitle className="text-xl font-medium">Emergency Card</CardTitle>
                  <Shield className="w-6 h-6 text-destructive" />
                </CardHeader>
                <CardContent>
                  <p className="text-base text-muted-foreground">
                    Quick access to critical medical information
                  </p>
                  <Button variant="outline" className="w-full mt-4" data-testid="button-show-emergency-card">
                    View Card
                  </Button>
                </CardContent>
              </Card>

              {/* Medications */}
              <Card className="hover-elevate cursor-pointer transition-all" onClick={() => setLocation('/medications')} data-testid="card-medications">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
                  <CardTitle className="text-xl font-medium">Medications</CardTitle>
                  <Pill className="w-6 h-6 text-primary" />
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex items-baseline gap-2">
                      <span className="text-4xl font-bold">{todayMeds.length}</span>
                      <span className="text-base text-muted-foreground">pending today</span>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {currentProfileMeds.length} active medications
                    </p>
                  </div>
                </CardContent>
              </Card>

              {/* Uploads */}
              <Card className="hover-elevate cursor-pointer transition-all" onClick={() => setLocation('/uploads')} data-testid="card-uploads">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
                  <CardTitle className="text-xl font-medium">Documents</CardTitle>
                  <FileText className="w-6 h-6 text-primary" />
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex items-baseline gap-2">
                      <span className="text-4xl font-bold">{currentProfileUploads.length}</span>
                      <span className="text-base text-muted-foreground">files stored</span>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Prescriptions, reports, scans
                    </p>
                  </div>
                </CardContent>
              </Card>
            </section>

            {/* Today's Medications */}
            {todayMeds.length > 0 && (
              <section>
                <Card>
                  <CardHeader>
                    <div className="flex items-center justify-between gap-4">
                      <div>
                        <CardTitle className="text-2xl">Today's Medications</CardTitle>
                        <CardDescription className="text-base mt-1">
                          {todayMeds.length} medication{todayMeds.length > 1 ? 's' : ''} pending
                        </CardDescription>
                      </div>
                      <Clock className="w-8 h-8 text-muted-foreground" />
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {todayMeds.slice(0, 3).map(med => (
                      <div key={med.id} className="flex items-center justify-between p-4 rounded-lg border hover-elevate">
                        <div className="flex-1">
                          <p className="text-lg font-medium">{med.name}</p>
                          <p className="text-base text-muted-foreground">{med.dosage} • {med.frequency}</p>
                        </div>
                        <Badge variant="secondary" className="text-sm">
                          {med.time || 'Anytime'}
                        </Badge>
                      </div>
                    ))}
                    {todayMeds.length > 3 && (
                      <Button 
                        variant="outline" 
                        className="w-full"
                        onClick={() => setLocation('/medications')}
                        data-testid="button-view-all-medications"
                      >
                        View All {todayMeds.length} Medications
                      </Button>
                    )}
                  </CardContent>
                </Card>
              </section>
            )}

            {/* Bottom Navigation */}
            <section className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Button
                data-testid="button-nav-medications"
                variant="outline"
                className="h-20 flex flex-col gap-2"
                onClick={() => setLocation('/medications')}
              >
                <Pill className="w-6 h-6" />
                <span>Medications</span>
              </Button>
              <Button
                data-testid="button-nav-uploads"
                variant="outline"
                className="h-20 flex flex-col gap-2"
                onClick={() => setLocation('/uploads')}
              >
                <Upload className="w-6 h-6" />
                <span>Upload</span>
              </Button>
              <Button
                data-testid="button-nav-profiles"
                variant="outline"
                className="h-20 flex flex-col gap-2"
                onClick={() => setLocation('/profiles')}
              >
                <Shield className="w-6 h-6" />
                <span>Profiles</span>
              </Button>
              <Button
                data-testid="button-nav-chat"
                variant="outline"
                className="h-20 flex flex-col gap-2"
                onClick={() => setLocation('/chat')}
              >
                <MessageCircle className="w-6 h-6" />
                <span>Health Chat</span>
              </Button>
            </section>
          </>
        )}
      </main>

      {/* SOS Button - Fixed Position */}
      <SosButton profileId={currentProfileId} />

      {/* Dialogs */}
      {currentProfile && (
        <EmergencyCardDialog
          open={showEmergencyCard}
          onOpenChange={setShowEmergencyCard}
          profile={currentProfile}
          onUpdate={loadData}
        />
      )}
      
      <AddProfileDialog
        open={showAddProfile}
        onOpenChange={setShowAddProfile}
        onProfileAdded={handleProfileAdded}
      />
    </div>
  );
}
