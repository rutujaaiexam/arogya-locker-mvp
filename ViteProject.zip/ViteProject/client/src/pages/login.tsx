import { useState } from 'react';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { loginPhone, verifyOtp } from '@/lib/api';
import { storage } from '@/lib/storage';
import { Shield, Phone } from 'lucide-react';
import heroImage from '@assets/generated_images/Family_health_trust_hero_5926b284.png';

export default function Login() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [step, setStep] = useState<'phone' | 'otp'>('phone');
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [loading, setLoading] = useState(false);

  const handlePhoneSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (phone.length < 10) {
      toast({
        title: 'Invalid phone number',
        description: 'Please enter a valid 10-digit phone number',
        variant: 'destructive',
      });
      return;
    }

    setLoading(true);
    try {
      const result = await loginPhone(phone);
      if (result.success) {
        toast({
          title: 'OTP Sent',
          description: 'For demo, enter any 6-digit code',
        });
        setStep('otp');
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to send OTP. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleOtpSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (otp.length !== 6) {
      toast({
        title: 'Invalid OTP',
        description: 'Please enter a 6-digit code',
        variant: 'destructive',
      });
      return;
    }

    setLoading(true);
    try {
      const result = await verifyOtp(phone, otp);
      if (result.success) {
        storage.setUser({ id: result.userId, phone, name: null, lastLoginAt: new Date().toISOString() });
        toast({
          title: 'Welcome!',
          description: 'Login successful',
        });
        setLocation('/dashboard');
      } else {
        toast({
          title: 'Invalid OTP',
          description: result.message,
          variant: 'destructive',
        });
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Login failed. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      {/* Hero Section */}
      <div className="relative w-full h-64 md:h-96 overflow-hidden">
        <img 
          src={heroImage} 
          alt="Family health and care" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-black/50 to-black/60" />
        <div className="absolute inset-0 flex flex-col items-center justify-center text-white px-4">
          <div className="flex items-center gap-3 mb-4">
            <Shield className="w-12 h-12" />
            <h1 className="text-4xl md:text-5xl font-semibold">Arogya Locker</h1>
          </div>
          <p className="text-lg md:text-xl text-white/90 max-w-2xl text-center">
            Your family's health guardian. Secure medical records, emergency information, and medication tracking in one place.
          </p>
        </div>
      </div>

      {/* Login Form */}
      <div className="flex-1 flex items-center justify-center p-4 md:p-8 bg-background">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="text-2xl">
              {step === 'phone' ? 'Sign In' : 'Verify OTP'}
            </CardTitle>
            <CardDescription className="text-lg">
              {step === 'phone' 
                ? 'Enter your phone number to receive a verification code' 
                : `We've sent a code to ${phone}`}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {step === 'phone' ? (
              <form onSubmit={handlePhoneSubmit} className="space-y-6" data-testid="form-phone">
                <div className="space-y-2">
                  <Label htmlFor="phone" className="text-lg font-medium">Phone Number</Label>
                  <div className="relative">
                    <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                    <Input
                      id="phone"
                      data-testid="input-phone"
                      type="tel"
                      placeholder="10-digit mobile number"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value.replace(/\D/g, '').slice(0, 10))}
                      className="h-14 pl-12 text-lg"
                      disabled={loading}
                      autoFocus
                    />
                  </div>
                </div>
                <Button 
                  type="submit" 
                  data-testid="button-send-otp"
                  className="w-full h-14 text-lg font-semibold"
                  disabled={loading || phone.length < 10}
                >
                  {loading ? 'Sending...' : 'Send OTP'}
                </Button>
                <p className="text-sm text-muted-foreground text-center">
                  Demo mode: Any 6-digit code will work for verification
                </p>
              </form>
            ) : (
              <form onSubmit={handleOtpSubmit} className="space-y-6" data-testid="form-otp">
                <div className="space-y-2">
                  <Label htmlFor="otp" className="text-lg font-medium">Verification Code</Label>
                  <Input
                    id="otp"
                    data-testid="input-otp"
                    type="text"
                    inputMode="numeric"
                    placeholder="Enter 6-digit code"
                    value={otp}
                    onChange={(e) => setOtp(e.target.value.replace(/\D/g, '').slice(0, 6))}
                    className="h-14 text-lg text-center tracking-widest"
                    disabled={loading}
                    autoFocus
                  />
                </div>
                <div className="space-y-3">
                  <Button 
                    type="submit" 
                    data-testid="button-verify-otp"
                    className="w-full h-14 text-lg font-semibold"
                    disabled={loading || otp.length !== 6}
                  >
                    {loading ? 'Verifying...' : 'Verify & Continue'}
                  </Button>
                  <Button 
                    type="button"
                    data-testid="button-change-phone"
                    variant="outline"
                    className="w-full h-14 text-lg"
                    onClick={() => {
                      setStep('phone');
                      setOtp('');
                    }}
                    disabled={loading}
                  >
                    Change Phone Number
                  </Button>
                </div>
              </form>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
