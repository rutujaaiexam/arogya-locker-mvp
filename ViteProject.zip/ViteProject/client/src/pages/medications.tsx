import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { storage } from '@/lib/storage';
import { ArrowLeft, Plus, CheckCircle2, Circle, Pill } from 'lucide-react';
import type { Medication, Profile } from '@shared/schema';
import emptyMedsImage from '@assets/generated_images/Empty_medication_state_illustration_f97df847.png';

const FREQUENCIES = ['Morning', 'Afternoon', 'Evening', 'Night'];

export default function Medications() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [currentProfileId, setCurrentProfileId] = useState<string | null>(null);
  const [medications, setMedications] = useState<Medication[]>([]);
  const [medicationLogs, setMedicationLogs] = useState<any[]>([]);
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    dosage: '',
    frequency: '',
    time: '',
    instructions: '',
  });

  useEffect(() => {
    const user = storage.getUser();
    if (!user) {
      setLocation('/');
      return;
    }

    loadData();
  }, []);

  const loadData = () => {
    const loadedProfiles = storage.getProfiles();
    const loadedMeds = storage.getMedications();
    const loadedLogs = storage.getMedicationLogs();

    setProfiles(loadedProfiles);
    setMedications(loadedMeds);
    setMedicationLogs(loadedLogs);

    if (loadedProfiles.length > 0 && !currentProfileId) {
      const primaryProfile = loadedProfiles.find(p => p.isPrimary) || loadedProfiles[0];
      setCurrentProfileId(primaryProfile.id);
    }
  };

  const handleAddMedication = () => {
    if (!currentProfileId || !formData.name.trim() || !formData.dosage.trim() || !formData.frequency) {
      toast({
        title: 'Missing information',
        description: 'Please fill in all required fields',
        variant: 'destructive',
      });
      return;
    }

    const newMed: Medication = {
      id: crypto.randomUUID(),
      profileId: currentProfileId,
      name: formData.name.trim(),
      dosage: formData.dosage.trim(),
      frequency: formData.frequency,
      time: formData.time || undefined,
      instructions: formData.instructions.trim() || undefined,
      isActive: true,
    };

    storage.setMedications([...medications, newMed]);
    setMedications([...medications, newMed]);
    
    setFormData({ name: '', dosage: '', frequency: '', time: '', instructions: '' });
    setShowAddDialog(false);

    toast({
      title: 'Medication added',
      description: `${formData.name} has been added to the schedule`,
    });
  };

  const handleToggleMedication = (medId: string) => {
    const today = new Date().toISOString().split('T')[0];
    const existingLog = medicationLogs.find(
      log => log.medicationId === medId && log.date === today
    );

    if (existingLog) {
      const updatedLogs = medicationLogs.filter(log => log.id !== existingLog.id);
      storage.setMedicationLogs(updatedLogs);
      setMedicationLogs(updatedLogs);
      toast({
        title: 'Unmarked',
        description: 'Medication marked as not taken',
      });
    } else {
      const newLog = {
        id: crypto.randomUUID(),
        medicationId: medId,
        profileId: currentProfileId!,
        takenAt: new Date().toISOString(),
        date: today,
      };
      const updatedLogs = [...medicationLogs, newLog];
      storage.setMedicationLogs(updatedLogs);
      setMedicationLogs(updatedLogs);
      toast({
        title: 'Medication taken',
        description: 'Great job staying on track!',
      });
    }
  };

  const currentProfile = profiles.find(p => p.id === currentProfileId);
  const profileMeds = medications.filter(m => m.profileId === currentProfileId && m.isActive);
  const today = new Date().toISOString().split('T')[0];

  const groupedMeds = FREQUENCIES.reduce((acc, freq) => {
    acc[freq] = profileMeds.filter(m => m.frequency === freq);
    return acc;
  }, {} as Record<string, Medication[]>);

  if (!currentProfile) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  }

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Header */}
      <header className="sticky top-0 z-40 border-b bg-card">
        <div className="max-w-6xl mx-auto px-4 md:px-8 py-4 flex items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <Button
              data-testid="button-back"
              variant="ghost"
              size="icon"
              onClick={() => setLocation('/dashboard')}
            >
              <ArrowLeft className="w-6 h-6" />
            </Button>
            <div>
              <h1 className="text-2xl md:text-3xl font-semibold">Medications</h1>
              <p className="text-base text-muted-foreground">{currentProfile.name}</p>
            </div>
          </div>
          <Button
            data-testid="button-add-medication"
            onClick={() => setShowAddDialog(true)}
            className="gap-2"
          >
            <Plus className="w-5 h-5" />
            <span className="hidden sm:inline">Add Medication</span>
          </Button>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 md:px-8 py-8">
        {profileMeds.length === 0 ? (
          <Card className="max-w-md mx-auto text-center">
            <CardContent className="pt-12 pb-12 space-y-6">
              <img 
                src={emptyMedsImage} 
                alt="No medications" 
                className="w-48 h-48 mx-auto opacity-60"
              />
              <div>
                <h2 className="text-2xl font-semibold mb-2">No medications yet</h2>
                <p className="text-lg text-muted-foreground mb-6">
                  Add medications to start tracking your schedule
                </p>
                <Button
                  data-testid="button-add-first-medication"
                  onClick={() => setShowAddDialog(true)}
                  size="lg"
                  className="gap-2"
                >
                  <Plus className="w-5 h-5" />
                  Add Your First Medication
                </Button>
              </div>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-8">
            {FREQUENCIES.map(frequency => {
              const meds = groupedMeds[frequency];
              if (meds.length === 0) return null;

              return (
                <section key={frequency}>
                  <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                    <Pill className="w-5 h-5" />
                    {frequency}
                  </h2>
                  <div className="space-y-3">
                    {meds.map(med => {
                      const isTakenToday = medicationLogs.some(
                        log => log.medicationId === med.id && log.date === today
                      );

                      return (
                        <Card 
                          key={med.id} 
                          className={`hover-elevate transition-all ${isTakenToday ? 'opacity-60' : ''}`}
                          data-testid={`card-medication-${med.id}`}
                        >
                          <CardContent className="p-6">
                            <div className="flex items-start gap-4">
                              <button
                                data-testid={`checkbox-medication-${med.id}`}
                                onClick={() => handleToggleMedication(med.id)}
                                className="mt-1"
                              >
                                {isTakenToday ? (
                                  <CheckCircle2 className="w-8 h-8 text-primary" />
                                ) : (
                                  <Circle className="w-8 h-8 text-muted-foreground hover:text-primary transition-colors" />
                                )}
                              </button>
                              <div className="flex-1 min-w-0">
                                <h3 className={`text-lg font-semibold ${isTakenToday ? 'line-through' : ''}`}>
                                  {med.name}
                                </h3>
                                <p className="text-base text-muted-foreground">
                                  {med.dosage}
                                </p>
                                {med.instructions && (
                                  <p className="text-sm text-muted-foreground mt-2">
                                    {med.instructions}
                                  </p>
                                )}
                              </div>
                              {med.time && (
                                <Badge variant="secondary" className="text-base">
                                  {med.time}
                                </Badge>
                              )}
                            </div>
                          </CardContent>
                        </Card>
                      );
                    })}
                  </div>
                </section>
              );
            })}
          </div>
        )}
      </main>

      {/* Add Medication Dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent data-testid="dialog-add-medication">
          <DialogHeader>
            <DialogTitle className="text-2xl">Add Medication</DialogTitle>
            <DialogDescription className="text-base">
              Create a new medication reminder
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="medName" className="text-lg font-medium">Medication Name *</Label>
              <Input
                id="medName"
                data-testid="input-medication-name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="e.g., Aspirin"
                className="h-14 text-lg"
                autoFocus
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="dosage" className="text-lg font-medium">Dosage *</Label>
              <Input
                id="dosage"
                data-testid="input-dosage"
                value={formData.dosage}
                onChange={(e) => setFormData({ ...formData, dosage: e.target.value })}
                placeholder="e.g., 500mg"
                className="h-14 text-lg"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="frequency" className="text-lg font-medium">Time of Day *</Label>
              <Select value={formData.frequency} onValueChange={(val) => setFormData({ ...formData, frequency: val })}>
                <SelectTrigger id="frequency" data-testid="select-frequency" className="h-14 text-lg">
                  <SelectValue placeholder="Select time" />
                </SelectTrigger>
                <SelectContent>
                  {FREQUENCIES.map(freq => (
                    <SelectItem key={freq} value={freq}>{freq}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="time" className="text-lg font-medium">Specific Time (Optional)</Label>
              <Input
                id="time"
                data-testid="input-time"
                type="time"
                value={formData.time}
                onChange={(e) => setFormData({ ...formData, time: e.target.value })}
                className="h-14 text-lg"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="instructions" className="text-lg font-medium">Instructions (Optional)</Label>
              <Input
                id="instructions"
                data-testid="input-instructions"
                value={formData.instructions}
                onChange={(e) => setFormData({ ...formData, instructions: e.target.value })}
                placeholder="e.g., Take with food"
                className="h-14 text-lg"
              />
            </div>

            <Button
              data-testid="button-save-medication"
              onClick={handleAddMedication}
              className="w-full h-14 text-lg font-semibold"
              disabled={!formData.name.trim() || !formData.dosage.trim() || !formData.frequency}
            >
              Add Medication
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
