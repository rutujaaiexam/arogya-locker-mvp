import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { useToast } from '@/hooks/use-toast';
import { storage } from '@/lib/storage';
import { AddProfileDialog } from '@/components/add-profile-dialog';
import { ArrowLeft, UserPlus, Trash2, Shield, Calendar } from 'lucide-react';
import type { Profile } from '@shared/schema';
import emptyProfilesImage from '@assets/generated_images/Empty_profiles_state_illustration_004f51f5.png';

export default function Profiles() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState<Profile | null>(null);

  useEffect(() => {
    const user = storage.getUser();
    if (!user) {
      setLocation('/');
      return;
    }

    loadProfiles();
  }, []);

  const loadProfiles = () => {
    setProfiles(storage.getProfiles());
  };

  const handleDeleteProfile = (profile: Profile) => {
    const updatedProfiles = profiles.filter(p => p.id !== profile.id);
    storage.setProfiles(updatedProfiles);

    const medications = storage.getMedications().filter(m => m.profileId !== profile.id);
    storage.setMedications(medications);

    const uploads = storage.getUploads().filter(u => u.profileId !== profile.id);
    storage.setUploads(uploads);

    const medicationLogs = storage.getMedicationLogs().filter(l => l.profileId !== profile.id);
    storage.setMedicationLogs(medicationLogs);

    loadProfiles();
    setDeleteConfirm(null);

    toast({
      title: 'Profile deleted',
      description: `${profile.name}'s profile has been removed`,
    });
  };

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Header */}
      <header className="sticky top-0 z-40 border-b bg-card">
        <div className="max-w-6xl mx-auto px-4 md:px-8 py-4 flex items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <Button
              data-testid="button-back"
              variant="ghost"
              size="icon"
              onClick={() => setLocation('/dashboard')}
            >
              <ArrowLeft className="w-6 h-6" />
            </Button>
            <div>
              <h1 className="text-2xl md:text-3xl font-semibold">Family Profiles</h1>
              <p className="text-base text-muted-foreground">{profiles.length} member{profiles.length !== 1 ? 's' : ''}</p>
            </div>
          </div>
          <Button
            data-testid="button-add-profile"
            onClick={() => setShowAddDialog(true)}
            className="gap-2"
          >
            <UserPlus className="w-5 h-5" />
            <span className="hidden sm:inline">Add Member</span>
          </Button>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 md:px-8 py-8">
        {profiles.length === 0 ? (
          <Card className="max-w-md mx-auto text-center">
            <CardContent className="pt-12 pb-12 space-y-6">
              <img 
                src={emptyProfilesImage} 
                alt="No profiles" 
                className="w-48 h-48 mx-auto opacity-60"
              />
              <div>
                <h2 className="text-2xl font-semibold mb-2">No profiles yet</h2>
                <p className="text-lg text-muted-foreground mb-6">
                  Create profiles for your family members to manage their health
                </p>
                <Button
                  data-testid="button-add-first-profile"
                  onClick={() => setShowAddDialog(true)}
                  size="lg"
                  className="gap-2"
                >
                  <UserPlus className="w-5 h-5" />
                  Add Your First Profile
                </Button>
              </div>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {profiles.map(profile => {
              const initials = profile.name
                .split(' ')
                .map(n => n[0])
                .join('')
                .toUpperCase()
                .slice(0, 2);

              return (
                <Card key={profile.id} className="hover-elevate transition-all" data-testid={`card-profile-${profile.id}`}>
                  <CardHeader>
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex items-center gap-4 flex-1">
                        <Avatar className="w-16 h-16">
                          <AvatarFallback 
                            className="text-xl font-semibold"
                            style={{ backgroundColor: profile.avatarColor }}
                          >
                            {initials}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <CardTitle className="text-xl truncate">{profile.name}</CardTitle>
                          {profile.relation && (
                            <CardDescription className="text-base">
                              {profile.relation}
                            </CardDescription>
                          )}
                        </div>
                      </div>
                      <Button
                        data-testid={`button-delete-${profile.id}`}
                        variant="ghost"
                        size="icon"
                        onClick={() => setDeleteConfirm(profile)}
                        className="text-destructive hover:text-destructive"
                      >
                        <Trash2 className="w-5 h-5" />
                      </Button>
                    </div>
                  </CardHeader>

                  <CardContent className="space-y-4">
                    {profile.dateOfBirth && (
                      <div className="flex items-center gap-2 text-sm">
                        <Calendar className="w-4 h-4 text-muted-foreground" />
                        <span>{profile.dateOfBirth}</span>
                      </div>
                    )}

                    {profile.bloodType && (
                      <Badge variant="secondary" className="text-sm">
                        Blood Type: {profile.bloodType}
                      </Badge>
                    )}

                    {profile.allergies && profile.allergies.length > 0 && (
                      <div>
                        <p className="text-sm font-medium mb-1">Allergies:</p>
                        <div className="flex flex-wrap gap-1">
                          {profile.allergies.map((allergy, i) => (
                            <Badge key={i} variant="destructive" className="text-xs">
                              {allergy}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}

                    {profile.isPrimary && (
                      <div className="pt-3 border-t">
                        <Badge variant="default" className="text-sm gap-1">
                          <Shield className="w-3 h-3" />
                          Primary Profile
                        </Badge>
                      </div>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </main>

      {/* Add Profile Dialog */}
      <AddProfileDialog
        open={showAddDialog}
        onOpenChange={setShowAddDialog}
        onProfileAdded={() => {
          loadProfiles();
          setShowAddDialog(false);
        }}
      />

      {/* Delete Confirmation Dialog */}
      {deleteConfirm && (
        <AlertDialog open={!!deleteConfirm} onOpenChange={() => setDeleteConfirm(null)}>
          <AlertDialogContent data-testid="dialog-delete-confirm">
            <AlertDialogHeader>
              <AlertDialogTitle className="text-2xl">Delete Profile?</AlertDialogTitle>
              <AlertDialogDescription className="text-base">
                This will permanently delete {deleteConfirm.name}'s profile and all associated data 
                (medications, uploads, logs). This action cannot be undone.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel data-testid="button-cancel-delete" className="h-12">Cancel</AlertDialogCancel>
              <AlertDialogAction
                data-testid="button-confirm-delete"
                onClick={() => handleDeleteProfile(deleteConfirm)}
                className="h-12 bg-destructive text-destructive-foreground hover:bg-destructive/90"
              >
                Delete Profile
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      )}
    </div>
  );
}
