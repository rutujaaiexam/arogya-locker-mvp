import { useState, useEffect, useRef } from 'react';
import { useLocation } from 'wouter';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { storage } from '@/lib/storage';
import { uploadFile } from '@/lib/api';
import { ArrowLeft, Upload as UploadIcon, FileText, Image, X } from 'lucide-react';
import type { Upload, Profile } from '@shared/schema';
import emptyUploadsImage from '@assets/generated_images/Empty_uploads_state_illustration_26a14e92.png';

const FILE_TYPES = [
  { value: 'prescription', label: 'Prescription' },
  { value: 'lab_report', label: 'Lab Report' },
  { value: 'x_ray', label: 'X-Ray / Scan' },
  { value: 'other', label: 'Other' },
];

export default function Uploads() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [currentProfileId, setCurrentProfileId] = useState<string | null>(null);
  const [uploads, setUploads] = useState<Upload[]>([]);
  const [showUploadDialog, setShowUploadDialog] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [fileType, setFileType] = useState('');
  const [notes, setNotes] = useState('');
  const [uploading, setUploading] = useState(false);
  const [viewingUpload, setViewingUpload] = useState<Upload | null>(null);

  useEffect(() => {
    const user = storage.getUser();
    if (!user) {
      setLocation('/');
      return;
    }

    loadData();
  }, []);

  const loadData = () => {
    const loadedProfiles = storage.getProfiles();
    const loadedUploads = storage.getUploads();

    setProfiles(loadedProfiles);
    setUploads(loadedUploads);

    if (loadedProfiles.length > 0 && !currentProfileId) {
      const primaryProfile = loadedProfiles.find(p => p.isPrimary) || loadedProfiles[0];
      setCurrentProfileId(primaryProfile.id);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 10 * 1024 * 1024) {
      toast({
        title: 'File too large',
        description: 'Please select a file smaller than 10MB',
        variant: 'destructive',
      });
      return;
    }

    setSelectedFile(file);

    if (file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = (e) => setPreview(e.target?.result as string);
      reader.readAsDataURL(file);
    } else {
      setPreview(null);
    }

    setShowUploadDialog(true);
  };

  const handleUpload = async () => {
    if (!selectedFile || !currentProfileId || !fileType) {
      toast({
        title: 'Missing information',
        description: 'Please select a file type',
        variant: 'destructive',
      });
      return;
    }

    setUploading(true);
    try {
      const result = await uploadFile(selectedFile);
      
      if (result.success) {
        const newUpload: Upload = {
          id: crypto.randomUUID(),
          profileId: currentProfileId,
          fileName: selectedFile.name,
          fileType,
          fileData: result.fileData,
          uploadedAt: new Date().toISOString(),
          notes: notes.trim() || undefined,
        };

        const updatedUploads = [...uploads, newUpload];
        storage.setUploads(updatedUploads);
        setUploads(updatedUploads);

        toast({
          title: 'Upload successful',
          description: result.extractedText 
            ? 'File uploaded and text extracted' 
            : 'File uploaded successfully',
        });

        resetUploadForm();
      } else {
        throw new Error(result.message);
      }
    } catch (error) {
      toast({
        title: 'Upload failed',
        description: 'Please try again',
        variant: 'destructive',
      });
    } finally {
      setUploading(false);
    }
  };

  const resetUploadForm = () => {
    setSelectedFile(null);
    setPreview(null);
    setFileType('');
    setNotes('');
    setShowUploadDialog(false);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const currentProfile = profiles.find(p => p.id === currentProfileId);
  const profileUploads = uploads.filter(u => u.profileId === currentProfileId);

  const groupedUploads = FILE_TYPES.reduce((acc, type) => {
    acc[type.value] = profileUploads.filter(u => u.fileType === type.value);
    return acc;
  }, {} as Record<string, Upload[]>);

  if (!currentProfile) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  }

  return (
    <div className="min-h-screen bg-background pb-24">
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*,.pdf"
        onChange={handleFileSelect}
        className="hidden"
      />

      {/* Header */}
      <header className="sticky top-0 z-40 border-b bg-card">
        <div className="max-w-6xl mx-auto px-4 md:px-8 py-4 flex items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <Button
              data-testid="button-back"
              variant="ghost"
              size="icon"
              onClick={() => setLocation('/dashboard')}
            >
              <ArrowLeft className="w-6 h-6" />
            </Button>
            <div>
              <h1 className="text-2xl md:text-3xl font-semibold">Medical Documents</h1>
              <p className="text-base text-muted-foreground">{currentProfile.name}</p>
            </div>
          </div>
          <Button
            data-testid="button-upload"
            onClick={() => fileInputRef.current?.click()}
            className="gap-2"
          >
            <UploadIcon className="w-5 h-5" />
            <span className="hidden sm:inline">Upload</span>
          </Button>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 md:px-8 py-8">
        {profileUploads.length === 0 ? (
          <Card className="max-w-md mx-auto text-center">
            <CardContent className="pt-12 pb-12 space-y-6">
              <img 
                src={emptyUploadsImage} 
                alt="No documents" 
                className="w-48 h-48 mx-auto opacity-60"
              />
              <div>
                <h2 className="text-2xl font-semibold mb-2">No documents yet</h2>
                <p className="text-lg text-muted-foreground mb-6">
                  Upload prescriptions, lab reports, and medical scans
                </p>
                <Button
                  data-testid="button-upload-first"
                  onClick={() => fileInputRef.current?.click()}
                  size="lg"
                  className="gap-2"
                >
                  <UploadIcon className="w-5 h-5" />
                  Upload Your First Document
                </Button>
              </div>
              <div className="pt-6 border-t border-dashed">
                <p className="text-sm text-muted-foreground">
                  Supported formats: Images (JPG, PNG) and PDF files up to 10MB
                </p>
              </div>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-8">
            {FILE_TYPES.map(type => {
              const typeUploads = groupedUploads[type.value];
              if (typeUploads.length === 0) return null;

              return (
                <section key={type.value}>
                  <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                    <FileText className="w-5 h-5" />
                    {type.label} ({typeUploads.length})
                  </h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {typeUploads.map(upload => (
                      <Card 
                        key={upload.id}
                        className="hover-elevate cursor-pointer transition-all"
                        onClick={() => setViewingUpload(upload)}
                        data-testid={`card-upload-${upload.id}`}
                      >
                        <CardHeader className="pb-3">
                          <div className="flex items-start justify-between gap-2">
                            <div className="flex-1 min-w-0">
                              <CardTitle className="text-lg truncate">{upload.fileName}</CardTitle>
                              <CardDescription className="text-sm">
                                {new Date(upload.uploadedAt).toLocaleDateString()}
                              </CardDescription>
                            </div>
                            {upload.fileData.startsWith('data:image/') ? (
                              <Image className="w-5 h-5 text-primary" />
                            ) : (
                              <FileText className="w-5 h-5 text-muted-foreground" />
                            )}
                          </div>
                        </CardHeader>
                        {upload.fileData.startsWith('data:image/') && (
                          <div className="px-6 pb-4">
                            <img 
                              src={upload.fileData} 
                              alt={upload.fileName}
                              className="w-full h-32 object-cover rounded-lg"
                            />
                          </div>
                        )}
                        {upload.notes && (
                          <CardContent className="pt-0">
                            <p className="text-sm text-muted-foreground line-clamp-2">
                              {upload.notes}
                            </p>
                          </CardContent>
                        )}
                      </Card>
                    ))}
                  </div>
                </section>
              );
            })}
          </div>
        )}
      </main>

      {/* Upload Dialog */}
      <Dialog open={showUploadDialog} onOpenChange={setShowUploadDialog}>
        <DialogContent data-testid="dialog-upload">
          <DialogHeader>
            <DialogTitle className="text-2xl">Upload Medical Document</DialogTitle>
            <DialogDescription className="text-base">
              Add details about this file
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6">
            {selectedFile && (
              <div className="p-4 bg-muted rounded-lg">
                <p className="font-medium">{selectedFile.name}</p>
                <p className="text-sm text-muted-foreground">
                  {(selectedFile.size / 1024).toFixed(1)} KB
                </p>
              </div>
            )}

            {preview && (
              <div className="relative">
                <img src={preview} alt="Preview" className="w-full rounded-lg max-h-64 object-contain" />
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="fileType" className="text-lg font-medium">Document Type *</Label>
              <Select value={fileType} onValueChange={setFileType}>
                <SelectTrigger id="fileType" data-testid="select-file-type" className="h-14 text-lg">
                  <SelectValue placeholder="Select type" />
                </SelectTrigger>
                <SelectContent>
                  {FILE_TYPES.map(type => (
                    <SelectItem key={type.value} value={type.value}>{type.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="notes" className="text-lg font-medium">Notes (Optional)</Label>
              <Textarea
                id="notes"
                data-testid="input-notes"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Add any notes about this document"
                className="min-h-24 text-base"
              />
            </div>

            <div className="flex gap-3">
              <Button
                data-testid="button-confirm-upload"
                onClick={handleUpload}
                className="flex-1 h-14 text-lg font-semibold gap-2"
                disabled={uploading || !fileType}
              >
                <UploadIcon className="w-5 h-5" />
                {uploading ? 'Uploading...' : 'Upload'}
              </Button>
              <Button
                data-testid="button-cancel-upload"
                variant="outline"
                onClick={resetUploadForm}
                className="h-14 px-6"
                disabled={uploading}
              >
                Cancel
              </Button>
            </div>

            <p className="text-sm text-muted-foreground text-center">
              Note: OCR text extraction will be available in future updates
            </p>
          </div>
        </DialogContent>
      </Dialog>

      {/* View Upload Dialog */}
      {viewingUpload && (
        <Dialog open={!!viewingUpload} onOpenChange={() => setViewingUpload(null)}>
          <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto" data-testid="dialog-view-upload">
            <DialogHeader>
              <DialogTitle className="text-2xl">{viewingUpload.fileName}</DialogTitle>
              <DialogDescription className="text-base">
                Uploaded on {new Date(viewingUpload.uploadedAt).toLocaleString()}
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4">
              <Badge variant="secondary" className="text-base">
                {FILE_TYPES.find(t => t.value === viewingUpload.fileType)?.label}
              </Badge>

              {viewingUpload.fileData.startsWith('data:image/') && (
                <img 
                  src={viewingUpload.fileData} 
                  alt={viewingUpload.fileName}
                  className="w-full rounded-lg"
                />
              )}

              {viewingUpload.notes && (
                <div>
                  <h3 className="font-semibold mb-2">Notes</h3>
                  <p className="text-base text-muted-foreground whitespace-pre-wrap">
                    {viewingUpload.notes}
                  </p>
                </div>
              )}
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
