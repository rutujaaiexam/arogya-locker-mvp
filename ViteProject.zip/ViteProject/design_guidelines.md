# Arogya Locker Design Guidelines

## Design Approach
**System-Based Approach** - Healthcare utility application requiring clarity, trust, and accessibility. Drawing from Material Design principles with healthcare-specific adaptations similar to MyChart and Apple Health, prioritizing legibility and user confidence over visual flair.

## Core Design Principles
1. **Medical Trust**: Clean, professional aesthetic that conveys reliability
2. **Immediate Clarity**: Critical functions (SOS, Emergency Card) must be instantly recognizable
3. **Gentle Accessibility**: Large touch targets, high contrast, forgiving interactions
4. **Progressive Disclosure**: Show essential info first, details on demand

## Typography

**Primary Font**: Inter (Google Fonts) - exceptional legibility at all sizes
**Secondary Font**: System UI fallback for data/numbers

- **Headings (H1)**: text-4xl (36px), font-semibold - page titles
- **Headings (H2)**: text-2xl (24px), font-semibold - section headers  
- **Headings (H3)**: text-xl (20px), font-medium - card titles
- **Body Large**: text-lg (18px), font-normal - primary content, form labels
- **Body**: text-base (16px), font-normal - secondary content
- **Small/Meta**: text-sm (14px), font-normal - timestamps, helper text
- **Button Text**: text-lg (18px), font-semibold - all interactive elements
- **Emergency/Critical**: text-2xl (24px), font-bold - SOS button, alerts

## Layout System

**Spacing Primitives**: Use Tailwind units of **4, 6, 8, 12, 16** for consistent rhythm
- Component padding: p-6 to p-8
- Section spacing: space-y-8 or gap-8  
- Card internal spacing: p-6
- Button padding: px-8 py-4 (generous touch targets)
- Page margins: px-4 (mobile), px-8 (desktop)

**Container Widths**:
- Dashboard max-width: max-w-6xl mx-auto
- Forms/Cards: max-w-2xl
- Emergency Card: max-w-md (compact, focused)

**Grid System**: Single column mobile, 2-column tablet for profiles/meds, 3-column desktop for quick-access cards

## Component Library

### Navigation
- **Top Bar**: Fixed header with app logo/title, profile switcher dropdown, logout
- **Bottom Nav (Mobile)**: 4-5 large icon tabs - Dashboard, Profiles, Medications, Emergency, Chat
- **Desktop Sidebar**: Vertical nav with icons + labels, collapsible

### Core Components

**Dashboard Cards**: Elevated cards (shadow-md) with rounded-xl corners, p-6 spacing, each showing one key metric or action (upcoming medication, emergency card quick-view, recent uploads)

**Profile Selector**: Large avatar circles (w-20 h-20) with names below, add profile as dashed circle with plus icon, horizontal scroll on mobile

**Emergency Card**: 
- Full-screen modal when activated
- Large readable sections: Blood Type, Allergies, Emergency Contacts, Medications
- High-contrast display optimized for first responders
- "Show Card" button is prominent with shield/medical icon

**SOS Button**:
- Fixed position bottom-right (desktop) or prominent top of dashboard
- Extra large (w-24 h-24), circular, red gradient treatment
- Phone/alert icon centered
- Press-and-hold interaction with circular progress indicator
- Haptic feedback simulation (visual pulse)

**Upload Zone**: 
- Dashed border card with large upload icon
- Clear "Tap to upload or drag file" text-lg
- Shows file preview thumbnail after upload
- Tag/categorize interface below (Prescription, Lab Report, X-Ray, etc.)

**Medication Schedule**:
- List view with time-based grouping (Morning, Afternoon, Evening, Night)
- Each med: large checkbox (w-8 h-8), medication name text-lg, dosage text-base, time badge
- Taken meds show with reduced opacity
- "Add Medication" floating action button

**Chat Interface**:
- Messages in bubbles, user messages align right, bot messages align left
- Input field with large send button
- Suggested quick-reply chips below input
- Medical context disclaimer at top

**Forms**:
- One input per line, full width
- Labels above inputs (text-lg font-medium)
- Input fields: h-14 minimum, rounded-lg, px-4
- Clear validation states (green check, red warning icon)
- Large primary buttons below form (w-full on mobile)

### Interactive Elements

**Buttons**:
- **Primary**: Large (h-14), rounded-xl, full width on mobile, shadow-sm, semibold text
- **Secondary**: Same size, outlined style
- **Danger** (Delete Profile): Red variant, requires confirmation modal
- **Icon Buttons**: Minimum w-12 h-12 for accessibility

**Modals/Dialogs**:
- Centered overlay with backdrop blur
- max-w-lg, rounded-2xl, p-8
- Clear close X in top-right
- Action buttons in footer (Cancel + Primary action)

**Badges/Pills**: 
- Medication status: rounded-full, px-4 py-1, text-sm
- Profile role tags: Family Member, Primary User, Child

## Images

**Onboarding/Login Hero**: Warm, reassuring image of diverse family or medical professional with patient - conveys trust and care (full-width, h-64 on mobile, h-96 on desktop)

**Empty States**: Simple illustrations (not photos) for empty medication list, no profiles yet, no uploads - friendly line art style

**Profile Avatars**: User-uploaded or colorful initial circles (no generic silhouettes)

**Emergency Card Icon**: Medical cross or shield icon, large and prominent

## Accessibility Implementations

- Minimum touch target: 44x44px (w-12 h-12) for all interactive elements
- Focus states: Thick 3px outline with offset on all focusable elements
- ARIA labels on all icon-only buttons
- High contrast ratios maintained (4.5:1 minimum for body text, 3:1 for large text)
- Skip-to-content link for keyboard navigation
- Error messages appear adjacent to form fields with icons
- Loading states with spinner + text description

## Animations

**Minimal and Purposeful Only**:
- SOS button: Pulse animation on press-and-hold
- Upload: Simple fade-in for success confirmation
- Profile switch: Gentle 200ms cross-fade
- Modal entry: Scale from 0.95 to 1 with fade (150ms)
- Checkbox toggle: Quick spring animation (100ms)
- **No scroll animations, no parallax, no decorative motion**

## Critical UX Patterns

**Confirmations**: All destructive actions (delete profile, clear medication) require two-step confirmation with clear warning text

**Success Feedback**: Green checkmark icon + confirmation message appears for 2 seconds after saves

**Error Handling**: Friendly, actionable error messages - "We couldn't save that. Please check your internet connection." with retry button

**Progressive Disclosure**: Show 3-5 most recent items, "View All" link to full list

**Loading States**: Skeleton screens for data-heavy views, spinners for actions

This design prioritizes user confidence, accessibility, and clarity over visual complexity—essential for a health application serving non-technical users and families managing critical medical information.