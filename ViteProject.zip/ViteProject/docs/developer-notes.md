# Developer Notes - Integration Guide

This document explains exactly where to add real integrations to replace the demo/mock functionality.

## 📍 File Locations Quick Reference

- **Client-side API calls:** `client/src/lib/api.ts`
- **Client-side storage:** `client/src/lib/storage.ts`
- **Server-side routes:** `server/routes.ts`
- **Server-side storage:** `server/storage.ts`
- **Data schemas:** `shared/schema.ts`

## 🔐 1. Firebase Authentication (Replace Demo OTP)

### Current Implementation
- File: `client/src/lib/api.ts`
- Functions: `loginPhone()` and `verifyOtp()`
- Status: Mocks - accepts any phone and 6-digit OTP

### How to Replace with Firebase Auth

1. **Install Firebase:**
   ```bash
   npm install firebase
   ```

2. **Create Firebase config file:**
   ```typescript
   // client/src/lib/firebase.ts
   import { initializeApp } from 'firebase/app';
   import { getAuth } from 'firebase/auth';

   const firebaseConfig = {
     apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
     authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
     projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
     // ... other config
   };

   const app = initializeApp(firebaseConfig);
   export const auth = getAuth(app);
   ```

3. **Replace in `api.ts`:**
   ```typescript
   import { signInWithPhoneNumber, RecaptchaVerifier } from 'firebase/auth';
   import { auth } from './firebase';

   export async function loginPhone(phone: string) {
     const appVerifier = new RecaptchaVerifier(/* ... */);
     const confirmationResult = await signInWithPhoneNumber(auth, phone, appVerifier);
     window.confirmationResult = confirmationResult;
     return { success: true, message: 'OTP sent' };
   }

   export async function verifyOtp(phone: string, otp: string) {
     const result = await window.confirmationResult.confirm(otp);
     const user = result.user;
     return { success: true, userId: user.uid };
   }
   ```

4. **Add Replit Secrets:**
   - `VITE_FIREBASE_API_KEY`
   - `VITE_FIREBASE_AUTH_DOMAIN`
   - `VITE_FIREBASE_PROJECT_ID`

## 💾 2. Firebase Firestore (Replace localStorage)

### Current Implementation
- File: `client/src/lib/storage.ts`
- All functions use `localStorage.getItem()` and `localStorage.setItem()`

### How to Replace with Firestore

1. **Install Firestore:**
   ```bash
   npm install firebase
   ```

2. **Update firebase.ts:**
   ```typescript
   import { getFirestore } from 'firebase/firestore';
   export const db = getFirestore(app);
   ```

3. **Replace `storage.ts` functions:**
   ```typescript
   import { collection, getDocs, addDoc, updateDoc, deleteDoc, doc } from 'firebase/firestore';
   import { db } from './firebase';

   export const storage = {
     async getProfiles() {
       const querySnapshot = await getDocs(collection(db, 'profiles'));
       return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
     },

     async setProfiles(profiles: any[]) {
       // Batch write to Firestore
       // ...implementation
     },

     // ... repeat for medications, uploads, etc.
   };
   ```

4. **Security Rules in Firebase Console:**
   ```
   rules_version = '2';
   service cloud.firestore {
     match /databases/{database}/documents {
       match /profiles/{profile} {
         allow read, write: if request.auth != null && request.auth.uid == resource.data.userId;
       }
       // ... add rules for other collections
     }
   }
   ```

## 🔍 3. Google Vision OCR (Upload Text Extraction)

### Current Implementation
- File: `client/src/lib/api.ts`
- Function: `uploadFile()`
- Line: Search for `// TODO: Call OCR API here`

### How to Add Google Vision

1. **Create server endpoint** (API keys should never be in frontend):
   ```typescript
   // server/routes.ts
   import vision from '@google-cloud/vision';

   app.post("/api/ocr", async (req, res) => {
     const client = new vision.ImageAnnotatorClient({
       apiKey: process.env.GOOGLE_VISION_API_KEY
     });

     const [result] = await client.textDetection(req.body.image);
     const detections = result.textAnnotations;
     const text = detections[0]?.description || '';

     res.json({ extractedText: text });
   });
   ```

2. **Update frontend `api.ts`:**
   ```typescript
   export async function uploadFile(file: File) {
     const reader = new FileReader();
     
     return new Promise((resolve) => {
       reader.onload = async () => {
         const base64 = reader.result as string;
         
         // Call your OCR endpoint
         const response = await fetch('/api/ocr', {
           method: 'POST',
           headers: { 'Content-Type': 'application/json' },
           body: JSON.stringify({ image: base64 })
         });
         
         const { extractedText } = await response.json();
         
         resolve({
           success: true,
           fileData: base64,
           extractedText,
           message: 'File uploaded and text extracted'
         });
       };
       
       reader.readAsDataURL(file);
     });
   }
   ```

3. **Add Secret:**
   - `GOOGLE_VISION_API_KEY`

## 🤖 4. OpenAI/LLM (Intelligent Chatbot)

### Current Implementation
- File: `client/src/lib/api.ts`
- Function: `getChatbotResponse()`
- Line: Search for `// TODO: Replace with actual LLM call`

### How to Add OpenAI

1. **Create server endpoint:**
   ```typescript
   // server/routes.ts
   import OpenAI from 'openai';

   const openai = new OpenAI({
     apiKey: process.env.OPENAI_API_KEY
   });

   app.post("/api/chat/ai-response", async (req, res) => {
     const { message, profileContext } = req.body;

     const systemPrompt = `You are a helpful health information assistant. 
     Provide general health guidance but always remind users to consult healthcare professionals for medical advice.
     User context: ${profileContext ? JSON.stringify(profileContext) : 'No profile context'}`;

     const completion = await openai.chat.completions.create({
       model: "gpt-4",
       messages: [
         { role: "system", content: systemPrompt },
         { role: "user", content: message }
       ],
     });

     res.json({ response: completion.choices[0].message.content });
   });
   ```

2. **Update frontend `api.ts`:**
   ```typescript
   export async function getChatbotResponse(message: string, profileContext?: Profile) {
     const response = await fetch('/api/chat/ai-response', {
       method: 'POST',
       headers: { 'Content-Type': 'application/json' },
       body: JSON.stringify({ message, profileContext })
     });

     const { response: botMessage } = await response.json();
     return botMessage;
   }
   ```

3. **Add Secret:**
   - `OPENAI_API_KEY`

## 📞 5. Twilio (SOS Emergency Calls/SMS)

### Current Implementation
- File: `client/src/lib/api.ts`
- Function: `sendSos()`
- Line: Search for `// TODO: Add actual API call here`

### How to Add Twilio

1. **Create server endpoint:**
   ```typescript
   // server/routes.ts
   import twilio from 'twilio';

   const twilioClient = twilio(
     process.env.TWILIO_ACCOUNT_SID,
     process.env.TWILIO_AUTH_TOKEN
   );

   app.post("/api/sos/trigger", async (req, res) => {
     const { profileId, location } = req.body;
     
     // Get profile with emergency contact
     const profile = await storage.getProfile(profileId);
     
     if (profile?.emergencyContactPhone) {
       // Send SMS
       await twilioClient.messages.create({
         body: `🚨 EMERGENCY ALERT: ${profile.name} triggered SOS. Location: ${location}`,
         from: process.env.TWILIO_PHONE_NUMBER,
         to: profile.emergencyContactPhone
       });

       // Optional: Make voice call
       await twilioClient.calls.create({
         twiml: '<Response><Say>Emergency alert for ' + profile.name + '</Say></Response>',
         from: process.env.TWILIO_PHONE_NUMBER,
         to: profile.emergencyContactPhone
       });
     }

     res.json({ success: true });
   });
   ```

2. **Update frontend `api.ts`:**
   ```typescript
   export async function sendSos(profileId: string, location?: string) {
     const response = await fetch('/api/sos/trigger', {
       method: 'POST',
       headers: { 'Content-Type': 'application/json' },
       body: JSON.stringify({ profileId, location })
     });

     const result = await response.json();
     return result;
   }
   ```

3. **Add Secrets:**
   - `TWILIO_ACCOUNT_SID`
   - `TWILIO_AUTH_TOKEN`
   - `TWILIO_PHONE_NUMBER` (your Twilio number)

## 🔄 6. n8n Workflow Automation

### Use Cases
- Medication reminders (daily push notifications)
- Appointment reminders
- Automated health report summaries
- Data backup workflows

### How to Integrate

1. **Create n8n workflow** with Webhook trigger

2. **Call from anywhere in the app:**
   ```typescript
   // Example: Medication reminder
   async function scheduleMedicationReminder(medication: Medication) {
     await fetch('https://your-n8n-instance.com/webhook/med-reminder', {
       method: 'POST',
       headers: { 'Content-Type': 'application/json' },
       body: JSON.stringify({
         medicationName: medication.name,
         dosage: medication.dosage,
         time: medication.time,
         profileId: medication.profileId
       })
     });
   }
   ```

3. **n8n Workflow Example:**
   - Trigger: Webhook (receive medication data)
   - Schedule: Cron node (run at medication time)
   - Action: Send email/SMS/push notification

## 🗄️ 7. Database Migration (In-Memory → PostgreSQL/Firestore)

### Current Implementation
- File: `server/storage.ts`
- Class: `MemStorage` (data clears on server restart)

### Option A: PostgreSQL with Drizzle ORM

Already partially set up! Just need to:

1. **Create PostgreSQL database** in Replit (use database tool)

2. **Update `storage.ts`:**
   ```typescript
   import { drizzle } from 'drizzle-orm/node-postgres';
   import { eq } from 'drizzle-orm';
   import * as schema from '@shared/schema';

   const db = drizzle(process.env.DATABASE_URL, { schema });

   export class DbStorage implements IStorage {
     async getProfile(id: string) {
       const [profile] = await db.select().from(schema.profiles).where(eq(schema.profiles.id, id));
       return profile;
     }
     // ... implement other methods
   }

   export const storage = new DbStorage();
   ```

3. **Run migrations:**
   ```bash
   npx drizzle-kit generate
   npx drizzle-kit migrate
   ```

### Option B: Firestore (See section 2 above)

## 📝 Quick Migration Checklist

When moving from MVP to production:

- [ ] Replace `api.ts` mock functions with real API calls
- [ ] Replace `storage.ts` localStorage with Firebase/PostgreSQL
- [ ] Move API keys from code to environment variables (Replit Secrets)
- [ ] Implement real authentication (Firebase Auth or custom backend)
- [ ] Add OCR integration for prescription scanning
- [ ] Add LLM integration for intelligent chatbot
- [ ] Add Twilio integration for SOS alerts
- [ ] Set up n8n workflows for reminders and automation
- [ ] Add data encryption for sensitive medical information
- [ ] Implement proper error handling and logging
- [ ] Add backup and disaster recovery
- [ ] Security audit (especially if handling real patient data)
- [ ] Compliance review (HIPAA if in US, GDPR if in EU)

## 🚨 Important Reminders

1. **Never commit API keys to code** - Always use environment variables
2. **Test with fake data first** - Don't use real medical data until security is production-ready
3. **Compliance matters** - Consult legal experts for medical data handling
4. **Backup everything** - Medical data is critical, implement automated backups
5. **Error handling** - Healthcare apps need robust error handling and offline support

## 🎯 Recommended Implementation Order

1. Firebase Auth (get real login working first)
2. Firestore/PostgreSQL (get data persisting in cloud)
3. Twilio SOS (critical safety feature)
4. OpenAI chatbot (user engagement)
5. Google Vision OCR (nice-to-have enhancement)
6. n8n automation (optimization)

---

Need help? All the placeholder code has comments with "TODO:" to guide you to the exact line numbers!
