# Quick Tutorial - How Arogya Locker Works

This is a plain-English explanation of how the app is built, designed for someone learning to code.

## 🏗️ High-Level Architecture

Think of the app as three main layers:

1. **Frontend (What you see)** - React components in `client/src/`
2. **Backend (Behind the scenes)** - Express server in `server/`
3. **Data Storage (Where info lives)** - Currently browser storage, will move to cloud

## 📂 Understanding the Folder Structure

```
arogya-locker/
├── client/               Your app's user interface
│   ├── src/
│   │   ├── pages/       Different screens (login, dashboard, etc.)
│   │   ├── components/  Reusable pieces (buttons, cards, dialogs)
│   │   └── lib/         Helper functions (storage, API calls)
│   └── index.html       The HTML that loads your React app
│
├── server/              Your app's backend
│   ├── routes.ts        API endpoints (like /api/profiles)
│   └── storage.ts       Database layer (in-memory for now)
│
├── shared/              Code used by both frontend and backend
│   └── schema.ts        Data structure definitions
│
└── docs/                Documentation you're reading now!
```

## 🎨 How the Frontend Works

### Pages = Screens

Each file in `client/src/pages/` is a different screen:

- `login.tsx` → Login screen
- `dashboard.tsx` → Main dashboard after login
- `medications.tsx` → Medication tracking
- `uploads.tsx` → Document upload
- `profiles.tsx` → Family member management
- `chat.tsx` → Health chatbot

### Components = Building Blocks

Components in `client/src/components/` are reusable pieces:

```typescript
// Example: A button that appears everywhere
<Button onClick={handleClick}>
  Save Profile
</Button>

// Example: A card that displays information
<Card>
  <CardHeader>
    <CardTitle>Emergency Card</CardTitle>
  </CardHeader>
  <CardContent>
    Blood Type: O+
  </CardContent>
</Card>
```

### How Pages Connect (Routing)

The app uses `wouter` for navigation:

```typescript
// In App.tsx
<Route path="/" component={Login} />
<Route path="/dashboard" component={Dashboard} />
<Route path="/medications" component={Medications} />
```

When you visit `/medications`, React loads the `Medications` component.

## 💾 How Data Storage Works (MVP Version)

Right now, everything is stored in your browser using `localStorage`:

```typescript
// Saving data
localStorage.setItem('arogya_profiles', JSON.stringify(profiles));

// Getting data back
const profiles = JSON.parse(localStorage.getItem('arogya_profiles') || '[]');
```

**Important:** This means:
- Data only exists on your current browser
- Clearing browser data = losing everything
- No sync between devices
- Not secure for real medical data

This is fine for testing, but for production you'll move to Firebase or a database.

## 🔄 How Frontend Talks to Backend (API Calls)

Even though we're using localStorage now, the code is structured as if there's a real backend. This makes migration easier later.

### Frontend → Backend Flow:

1. **User clicks "Add Medication"**
2. **Frontend calls function** in `api.ts`:
   ```typescript
   const newMed = await createMedication(medicationData);
   ```
3. **Function stores data** in localStorage (for now):
   ```typescript
   const meds = storage.getMedications();
   meds.push(newMed);
   storage.setMedications(meds);
   ```
4. **Frontend gets response** and updates the UI

### Future: Real Backend

When you add a real backend, you'll just change `api.ts` to make HTTP calls:

```typescript
// Instead of localStorage
const response = await fetch('/api/medications', {
  method: 'POST',
  body: JSON.stringify(medicationData)
});
const newMed = await response.json();
```

The rest of your app stays the same!

## 🎯 How a Feature Works End-to-End

Let's follow "Adding a Medication" through the entire app:

### Step 1: User Interface (`medications.tsx`)

```typescript
// User clicks "Add Medication" button
<Button onClick={() => setShowAddDialog(true)}>
  Add Medication
</Button>

// Dialog appears with form
<Dialog open={showAddDialog}>
  <Input value={formData.name} onChange={...} />
  <Input value={formData.dosage} onChange={...} />
  <Select value={formData.frequency} onChange={...} />
  <Button onClick={handleAddMedication}>Save</Button>
</Dialog>
```

### Step 2: Form Submission (`medications.tsx`)

```typescript
const handleAddMedication = () => {
  // Validate input
  if (!formData.name.trim()) {
    toast({ title: 'Error', description: 'Name required' });
    return;
  }

  // Create medication object
  const newMed = {
    id: crypto.randomUUID(),
    profileId: currentProfileId,
    name: formData.name,
    dosage: formData.dosage,
    frequency: formData.frequency,
    // ... other fields
  };

  // Save it
  storage.setMedications([...medications, newMed]);
  
  // Update local state (so UI refreshes)
  setMedications([...medications, newMed]);
  
  // Close dialog
  setShowAddDialog(false);
  
  // Show success message
  toast({ title: 'Medication added!' });
};
```

### Step 3: Data Storage (`storage.ts`)

```typescript
export const storage = {
  getMedications() {
    return JSON.parse(localStorage.getItem('arogya_medications') || '[]');
  },
  
  setMedications(medications: any[]) {
    localStorage.setItem('arogya_medications', JSON.stringify(medications));
  },
};
```

### Step 4: Display Updates Automatically

React automatically re-renders the component because state changed:

```typescript
const [medications, setMedications] = useState([]);

// When setMedications() is called, React re-renders with new data
return (
  <div>
    {medications.map(med => (
      <Card key={med.id}>
        <h3>{med.name}</h3>
        <p>{med.dosage}</p>
      </Card>
    ))}
  </div>
);
```

## 🎨 How Styling Works

The app uses Tailwind CSS for styling:

```typescript
// Instead of writing CSS files
<div className="flex items-center gap-4 p-6 rounded-lg bg-card">
  <Button className="h-14 w-full text-lg font-semibold">
    Save
  </Button>
</div>
```

What this means:
- `flex` = flexbox layout
- `items-center` = vertically center items
- `gap-4` = 16px space between items
- `p-6` = 24px padding
- `rounded-lg` = rounded corners
- `bg-card` = background color from theme
- `h-14` = 56px height
- `w-full` = 100% width

Colors come from `index.css`:
```css
--primary: 210 85% 45%;  /* Blue color */
--card: 0 0% 98%;        /* Light gray */
```

## 🔍 How to Find Things

### Need to change login screen?
→ `client/src/pages/login.tsx`

### Need to change how medications are saved?
→ `client/src/lib/storage.ts`

### Need to add a new button component?
→ `client/src/components/ui/button.tsx`

### Need to change colors/fonts?
→ `client/src/index.css`

### Need to add a new page?
1. Create `client/src/pages/your-page.tsx`
2. Add route in `client/src/App.tsx`:
   ```typescript
   <Route path="/your-page" component={YourPage} />
   ```

## 🐛 Debugging Tips

### "Nothing happens when I click a button"
1. Check browser console (F12) for errors
2. Make sure `onClick={handleClick}` is wired up
3. Check if `handleClick` function exists and has no errors

### "Data disappeared after refresh"
This is normal with localStorage! Data clears when:
- You clear browser data
- You use incognito/private mode
- Server restarts (for backend data)

### "Can't see my changes"
1. Make sure Vite dev server is running (`npm run dev`)
2. Hard refresh (Ctrl+Shift+R or Cmd+Shift+R)
3. Check for TypeScript/build errors in terminal

### "TypeScript errors"
The red squiggly lines are helpful! They prevent bugs:
```typescript
// ❌ Bad: TypeScript will complain
const age: number = "25";

// ✅ Good: Correct type
const age: number = 25;
```

## 🚀 Making Your First Change

Want to try editing something? Here's an easy one:

1. **Open** `client/src/pages/dashboard.tsx`

2. **Find** this line (around line 95):
   ```typescript
   <h1 className="text-2xl md:text-3xl font-semibold">Arogya Locker</h1>
   ```

3. **Change** "Arogya Locker" to "My Health App":
   ```typescript
   <h1 className="text-2xl md:text-3xl font-semibold">My Health App</h1>
   ```

4. **Save** the file

5. **Check** your browser - the title changed!

Congratulations! You just made your first edit. 🎉

## 📚 Learning More

### React Concepts Used
- **useState** = Store data that changes (like form inputs)
- **useEffect** = Run code when component loads
- **Components** = Reusable pieces of UI
- **Props** = Data passed to components

### TypeScript Concepts
- **Types** = Define what kind of data a variable holds
- **Interfaces** = Define the shape of an object
- **Generics** = Make components work with different data types

### Want to Learn More?
- React official docs: https://react.dev
- TypeScript handbook: https://www.typescriptlang.org/docs/
- Tailwind CSS: https://tailwindcss.com/docs

## 🎯 Next Steps

Once you understand the basics:

1. **Add a simple feature** - Try adding a new field to profiles
2. **Customize the design** - Change colors in `index.css`
3. **Add an API integration** - Follow `developer-notes.md` to add Firebase
4. **Test on mobile** - Replit shows you a preview URL to test on your phone

---

Remember: Every expert was once a beginner. Take it one step at a time! 🌱
