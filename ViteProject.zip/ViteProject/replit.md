# Arogya Locker - Family Health Guardian

## Overview

Arogya Locker is a secure medical locker and health management application designed for individuals and families. The application allows users to store prescriptions, track medications, manage emergency medical cards, and access health information. This is an MVP (Minimum Viable Product) implementation that demonstrates core functionality using client-side storage, with a clear architecture that supports future migration to cloud-based services.

**Primary Purpose**: Provide a trusted, accessible platform for families to manage medical records, medication schedules, and emergency health information.

**Current State**: Fully functional MVP using localStorage for data persistence. All features are operational for demonstration and testing purposes.

**Target Users**: Non-technical users, families, and individuals with chronic conditions requiring organized health information management.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture (React + Vite)

**Framework**: React 18 with Vite for fast development and optimized builds

**Routing**: Wouter for lightweight client-side routing
- Single-page application with multiple views
- Routes: `/` (login), `/dashboard`, `/medications`, `/uploads`, `/profiles`, `/chat`

**State Management**: React hooks (useState, useEffect, useContext)
- Component-level state for UI interactions
- LocalStorage abstraction layer (`client/src/lib/storage.ts`) for data persistence
- TanStack Query for future server-side data management (infrastructure ready)

**UI Component System**: Radix UI primitives with custom styling
- Design system based on shadcn/ui components
- Tailwind CSS for utility-first styling
- Healthcare-focused design principles: high contrast, large touch targets (44px minimum), clear typography
- Inter font family for exceptional legibility
- Accessible components following WCAG guidelines

**Key Design Patterns**:
- **Progressive Disclosure**: Essential information first, details on demand
- **Accessibility First**: Large touch targets, high contrast ratios, keyboard navigation
- **Medical Trust Aesthetic**: Clean, professional design conveying reliability

### Backend Architecture (Express.js)

**Server Framework**: Express.js with TypeScript
- RESTful API structure in `server/routes.ts`
- Middleware for JSON parsing, logging, and error handling
- Demo authentication endpoints (ready for Firebase/Twilio replacement)

**Current Implementation**: In-memory storage (`server/storage.ts`)
- Abstract storage interface (`IStorage`) enables easy database migration
- All CRUD operations defined with clear contracts
- Data cleared on server restart (intentional for MVP)

**API Endpoints**:
- Authentication: `/api/auth/login`, `/api/auth/verify`
- Profiles: CRUD operations for family member profiles
- Medications: Schedule management and logging
- Uploads: Document storage (currently base64 in localStorage)
- SOS Events: Emergency alert logging
- Chat: Health chatbot messages

**Migration Path**: Storage interface designed to swap in-memory implementation with database (PostgreSQL via Drizzle ORM, or Firestore)

### Data Layer

**Current Storage**: Browser localStorage (client-side only)
- Abstraction layer in `client/src/lib/storage.ts`
- Structured keys: `arogya_user`, `arogya_profiles`, `arogya_medications`, etc.
- No server-side persistence in MVP (intentional)

**Data Schema** (defined in `shared/schema.ts`):
- **Users**: Phone-based authentication records
- **Profiles**: Family member health profiles (name, relation, DOB, blood type, allergies, chronic conditions)
- **Medications**: Scheduled medications with dosage, frequency, timing
- **Medication Logs**: Check-off records for taken doses
- **Uploads**: Medical documents (prescriptions, lab reports, X-rays)
- **SOS Events**: Emergency alert logs with timestamps and location
- **Chat Messages**: Conversational health bot interactions

**Future Database**: Drizzle ORM configuration ready for PostgreSQL
- Schema definitions using Drizzle's type-safe API
- Migration folder structure in place
- `drizzle.config.ts` configured for PostgreSQL connection

### Authentication Strategy

**Current (Demo)**: Phone number + OTP simulation
- Accepts any 10-digit phone number
- Accepts any 6-digit OTP code
- Stores demo user in localStorage

**Production Ready**: Firebase Authentication or Twilio integration
- Clear replacement points in `client/src/lib/api.ts`
- Documentation in `docs/developer-notes.md` for exact integration steps
- Server-side verification endpoints scaffolded

### File Upload System

**Current**: Base64 encoding in localStorage
- Files converted to base64 strings
- Stored with metadata (type, upload date, associated profile)
- Image preview support for uploaded documents

**Production Ready**: Cloud storage integration (Firebase Storage, AWS S3)
- Placeholder in `client/src/lib/api.ts` for `uploadFile()` function
- OCR integration point for prescription text extraction (Google Vision API)
- Document categorization system (prescription, lab report, X-ray, other)

### SOS Emergency System

**Current**: 3-second press-and-hold button
- Visual progress indicator (0-100%)
- Logs event to localStorage
- Toast notification on trigger

**Production Ready**: Webhook integration for real alerts
- Placeholder in `client/src/lib/api.ts` for `/api/sos` endpoint
- Designed for Twilio SMS/call integration or n8n workflow automation
- GPS location capture ready (browser geolocation API)

### Health Chatbot

**Current**: Rule-based responses (simple keyword matching)
- Hardcoded Q&A pairs in `getChatbotResponse()` function
- Suggested questions for user guidance
- Message history stored in localStorage

**Production Ready**: LLM integration (OpenAI, Anthropic)
- Replace rule-based logic with API calls
- Conversational context maintained in chat history
- Health-specific prompt engineering

## External Dependencies

### UI Component Libraries
- **Radix UI**: Headless accessible components (@radix-ui/react-*)
  - Dialog, Dropdown, Select, Toast, Avatar, and 20+ primitives
  - Fully accessible, keyboard navigable, screen reader compatible
- **shadcn/ui**: Pre-styled component templates using Radix + Tailwind
- **Lucide React**: Icon library for consistent iconography

### State & Data Management
- **TanStack Query** (@tanstack/react-query): Server state management (ready for API integration)
- **React Hook Form** (@hookform/resolvers): Form validation and management
- **Zod**: Schema validation for type-safe data contracts

### Styling & Design
- **Tailwind CSS**: Utility-first CSS framework
- **class-variance-authority**: Component variant management
- **clsx + tailwind-merge**: Conditional className utilities
- **Google Fonts (Inter)**: Primary typeface for medical legibility

### Database & ORM (Ready, Not Active)
- **Drizzle ORM** (drizzle-orm): TypeScript ORM for PostgreSQL
- **Drizzle Kit** (drizzle-kit): Schema migrations and management
- **Neon Serverless** (@neondatabase/serverless): PostgreSQL driver for serverless environments
- **Note**: Database dependencies installed but not actively used in MVP; localStorage serves as data layer

### Server & Build Tools
- **Express.js**: Backend HTTP server
- **Vite**: Frontend build tool and dev server
- **esbuild**: JavaScript bundler for production builds
- **tsx**: TypeScript execution for development

### Authentication (Planned Integration)
- **Firebase SDK** (not yet installed): For Auth + Firestore migration
- **Twilio SDK** (not yet installed): For real SMS OTP verification

### Future Service Integrations (Placeholders Ready)
- **Google Cloud Vision API**: OCR for prescription text extraction
- **OpenAI/Anthropic API**: LLM-powered health chatbot
- **Twilio API**: SMS notifications and emergency calls
- **n8n Webhooks**: Automation workflows for SOS alerts
- **Firebase**: Authentication, Firestore database, Cloud Storage

### Development Tools
- **TypeScript**: Type safety across full stack
- **Wouter**: Lightweight routing library
- **date-fns**: Date manipulation utilities
- **Replit Plugins**: Runtime error overlay, dev banner, code cartography