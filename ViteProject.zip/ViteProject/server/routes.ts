import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertUserSchema,
  insertProfileSchema,
  insertMedicationSchema,
  insertMedicationLogSchema,
  insertUploadSchema,
  insertSosEventSchema,
  insertChatMessageSchema,
} from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // ============================================================
  // AUTHENTICATION ROUTES
  // ============================================================
  // Demo OTP login - in production, integrate with Firebase/Twilio
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { phone } = req.body;
      
      if (!phone || phone.length < 10) {
        return res.status(400).json({ error: "Invalid phone number" });
      }

      // In production: Send actual OTP via Twilio/SMS service
      // For demo: Just simulate success
      res.json({ 
        success: true, 
        message: "OTP sent successfully (demo mode)" 
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to send OTP" });
    }
  });

  app.post("/api/auth/verify", async (req, res) => {
    try {
      const { phone, otp } = req.body;
      
      if (!phone || !otp || otp.length !== 6) {
        return res.status(400).json({ error: "Invalid credentials" });
      }

      // In production: Verify actual OTP
      // For demo: Accept any 6-digit code
      let user = await storage.getUserByPhone(phone);
      
      if (!user) {
        user = await storage.createUser({ phone, name: null });
      } else {
        user = await storage.updateUserLogin(user.id) || user;
      }

      res.json({ 
        success: true, 
        userId: user.id,
        message: "Login successful" 
      });
    } catch (error) {
      res.status(500).json({ error: "Login failed" });
    }
  });

  // ============================================================
  // PROFILE ROUTES
  // ============================================================
  app.get("/api/profiles/:userId", async (req, res) => {
    try {
      const profiles = await storage.getProfilesByUser(req.params.userId);
      res.json(profiles);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch profiles" });
    }
  });

  app.post("/api/profiles", async (req, res) => {
    try {
      const data = insertProfileSchema.parse(req.body);
      const profile = await storage.createProfile(data);
      res.json(profile);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create profile" });
    }
  });

  app.patch("/api/profiles/:id", async (req, res) => {
    try {
      const updates = req.body;
      const profile = await storage.updateProfile(req.params.id, updates);
      
      if (!profile) {
        return res.status(404).json({ error: "Profile not found" });
      }
      
      res.json(profile);
    } catch (error) {
      res.status(500).json({ error: "Failed to update profile" });
    }
  });

  app.delete("/api/profiles/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteProfile(req.params.id);
      
      if (!deleted) {
        return res.status(404).json({ error: "Profile not found" });
      }
      
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete profile" });
    }
  });

  // ============================================================
  // MEDICATION ROUTES
  // ============================================================
  app.get("/api/medications/:profileId", async (req, res) => {
    try {
      const medications = await storage.getMedicationsByProfile(req.params.profileId);
      res.json(medications);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch medications" });
    }
  });

  app.post("/api/medications", async (req, res) => {
    try {
      const data = insertMedicationSchema.parse(req.body);
      const medication = await storage.createMedication(data);
      res.json(medication);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create medication" });
    }
  });

  app.patch("/api/medications/:id", async (req, res) => {
    try {
      const updates = req.body;
      const medication = await storage.updateMedication(req.params.id, updates);
      
      if (!medication) {
        return res.status(404).json({ error: "Medication not found" });
      }
      
      res.json(medication);
    } catch (error) {
      res.status(500).json({ error: "Failed to update medication" });
    }
  });

  app.delete("/api/medications/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteMedication(req.params.id);
      
      if (!deleted) {
        return res.status(404).json({ error: "Medication not found" });
      }
      
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete medication" });
    }
  });

  // ============================================================
  // MEDICATION LOG ROUTES
  // ============================================================
  app.get("/api/medication-logs/:profileId", async (req, res) => {
    try {
      const logs = await storage.getMedicationLogsByProfile(req.params.profileId);
      res.json(logs);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch medication logs" });
    }
  });

  app.post("/api/medication-logs", async (req, res) => {
    try {
      const data = insertMedicationLogSchema.parse(req.body);
      const log = await storage.createMedicationLog(data);
      res.json(log);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create medication log" });
    }
  });

  app.delete("/api/medication-logs/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteMedicationLog(req.params.id);
      
      if (!deleted) {
        return res.status(404).json({ error: "Log not found" });
      }
      
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete medication log" });
    }
  });

  // ============================================================
  // UPLOAD ROUTES
  // ============================================================
  app.get("/api/uploads/:profileId", async (req, res) => {
    try {
      const uploads = await storage.getUploadsByProfile(req.params.profileId);
      res.json(uploads);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch uploads" });
    }
  });

  app.post("/api/uploads", async (req, res) => {
    try {
      const data = insertUploadSchema.parse(req.body);
      const upload = await storage.createUpload(data);
      res.json(upload);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create upload" });
    }
  });

  app.delete("/api/uploads/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteUpload(req.params.id);
      
      if (!deleted) {
        return res.status(404).json({ error: "Upload not found" });
      }
      
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete upload" });
    }
  });

  // ============================================================
  // SOS EVENT ROUTES
  // ============================================================
  // Placeholder for future Twilio/n8n integration
  app.post("/api/sos", async (req, res) => {
    try {
      const data = insertSosEventSchema.parse(req.body);
      
      // TODO: Add actual emergency notification logic here
      // Example: Call Twilio API to send SMS/voice call
      // Example: Trigger n8n webhook for automation
      console.log("[SOS TRIGGERED]", {
        profileId: data.profileId,
        location: data.location,
        timestamp: new Date().toISOString(),
      });
      
      const event = await storage.createSosEvent(data);
      
      res.json({ 
        success: true, 
        eventId: event.id,
        message: "Emergency alert sent (demo mode)" 
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to trigger SOS" });
    }
  });

  app.get("/api/sos-events/:profileId", async (req, res) => {
    try {
      const events = await storage.getSosEventsByProfile(req.params.profileId);
      res.json(events);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch SOS events" });
    }
  });

  // ============================================================
  // CHAT ROUTES
  // ============================================================
  app.get("/api/chat/:profileId", async (req, res) => {
    try {
      const messages = await storage.getChatMessagesByProfile(req.params.profileId);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch chat messages" });
    }
  });

  app.post("/api/chat", async (req, res) => {
    try {
      const data = insertChatMessageSchema.parse(req.body);
      const message = await storage.createChatMessage(data);
      res.json(message);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create chat message" });
    }
  });

  // Chatbot response endpoint - placeholder for OpenAI/LLM integration
  app.post("/api/chat/bot-response", async (req, res) => {
    try {
      const { message, profileId } = req.body;
      
      if (!message || !profileId) {
        return res.status(400).json({ error: "Message and profileId required" });
      }

      // TODO: Replace with actual LLM API call (OpenAI, etc.)
      // For now, return simple rule-based response
      const lowerMessage = message.toLowerCase();
      let response = "I'm here to provide general health information. For specific medical advice, please consult with a healthcare professional. How else can I assist you today?";

      if (lowerMessage.includes('hello') || lowerMessage.includes('hi')) {
        response = "Hello! I'm here to help with your health questions. Please remember, I provide general information only and cannot replace professional medical advice.";
      } else if (lowerMessage.includes('medicine') || lowerMessage.includes('medication')) {
        response = "I can help you understand medication information. For specific dosing questions, please consult your doctor or pharmacist. Would you like to set a medication reminder?";
      } else if (lowerMessage.includes('emergency') || lowerMessage.includes('help')) {
        response = "For medical emergencies, please call emergency services immediately or use the SOS button in the app. I'm here for general health information only.";
      }

      res.json({ response });
    } catch (error) {
      res.status(500).json({ error: "Failed to get bot response" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
