import { randomUUID } from "crypto";
import type {
  User,
  InsertUser,
  Profile,
  InsertProfile,
  Medication,
  InsertMedication,
  MedicationLog,
  InsertMedicationLog,
  Upload,
  InsertUpload,
  SosEvent,
  InsertSosEvent,
  ChatMessage,
  InsertChatMessage,
} from "@shared/schema";

// Storage interface for Arogya Locker
// This is abstracted to allow easy migration from in-memory to database storage
// For MVP: Uses in-memory storage (data cleared on server restart)
// For Production: Replace with database implementation (Firestore, PostgreSQL, etc.)

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByPhone(phone: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserLogin(id: string): Promise<User | undefined>;

  // Profile operations
  getProfile(id: string): Promise<Profile | undefined>;
  getProfilesByUser(userId: string): Promise<Profile[]>;
  createProfile(profile: InsertProfile): Promise<Profile>;
  updateProfile(id: string, updates: Partial<Profile>): Promise<Profile | undefined>;
  deleteProfile(id: string): Promise<boolean>;

  // Medication operations
  getMedication(id: string): Promise<Medication | undefined>;
  getMedicationsByProfile(profileId: string): Promise<Medication[]>;
  createMedication(medication: InsertMedication): Promise<Medication>;
  updateMedication(id: string, updates: Partial<Medication>): Promise<Medication | undefined>;
  deleteMedication(id: string): Promise<boolean>;

  // Medication log operations
  getMedicationLogsByProfile(profileId: string): Promise<MedicationLog[]>;
  createMedicationLog(log: InsertMedicationLog): Promise<MedicationLog>;
  deleteMedicationLog(id: string): Promise<boolean>;

  // Upload operations
  getUpload(id: string): Promise<Upload | undefined>;
  getUploadsByProfile(profileId: string): Promise<Upload[]>;
  createUpload(upload: InsertUpload): Promise<Upload>;
  deleteUpload(id: string): Promise<boolean>;

  // SOS event operations
  getSosEventsByProfile(profileId: string): Promise<SosEvent[]>;
  createSosEvent(event: InsertSosEvent): Promise<SosEvent>;

  // Chat message operations
  getChatMessagesByProfile(profileId: string): Promise<ChatMessage[]>;
  createChatMessage(message: InsertChatMessage): Promise<ChatMessage>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private profiles: Map<string, Profile>;
  private medications: Map<string, Medication>;
  private medicationLogs: Map<string, MedicationLog>;
  private uploads: Map<string, Upload>;
  private sosEvents: Map<string, SosEvent>;
  private chatMessages: Map<string, ChatMessage>;

  constructor() {
    this.users = new Map();
    this.profiles = new Map();
    this.medications = new Map();
    this.medicationLogs = new Map();
    this.uploads = new Map();
    this.sosEvents = new Map();
    this.chatMessages = new Map();
  }

  // User operations
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByPhone(phone: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find((user) => user.phone === phone);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { 
      ...insertUser, 
      id,
      lastLoginAt: new Date().toISOString() as any,
    };
    this.users.set(id, user);
    return user;
  }

  async updateUserLogin(id: string): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updated = { ...user, lastLoginAt: new Date().toISOString() as any };
    this.users.set(id, updated);
    return updated;
  }

  // Profile operations
  async getProfile(id: string): Promise<Profile | undefined> {
    return this.profiles.get(id);
  }

  async getProfilesByUser(userId: string): Promise<Profile[]> {
    return Array.from(this.profiles.values()).filter(p => p.userId === userId);
  }

  async createProfile(insertProfile: InsertProfile): Promise<Profile> {
    const id = randomUUID();
    const profile: Profile = { ...insertProfile, id } as Profile;
    this.profiles.set(id, profile);
    return profile;
  }

  async updateProfile(id: string, updates: Partial<Profile>): Promise<Profile | undefined> {
    const profile = this.profiles.get(id);
    if (!profile) return undefined;
    
    const updated = { ...profile, ...updates };
    this.profiles.set(id, updated);
    return updated;
  }

  async deleteProfile(id: string): Promise<boolean> {
    return this.profiles.delete(id);
  }

  // Medication operations
  async getMedication(id: string): Promise<Medication | undefined> {
    return this.medications.get(id);
  }

  async getMedicationsByProfile(profileId: string): Promise<Medication[]> {
    return Array.from(this.medications.values()).filter(m => m.profileId === profileId);
  }

  async createMedication(insertMedication: InsertMedication): Promise<Medication> {
    const id = randomUUID();
    const medication: Medication = { ...insertMedication, id } as Medication;
    this.medications.set(id, medication);
    return medication;
  }

  async updateMedication(id: string, updates: Partial<Medication>): Promise<Medication | undefined> {
    const medication = this.medications.get(id);
    if (!medication) return undefined;
    
    const updated = { ...medication, ...updates };
    this.medications.set(id, updated);
    return updated;
  }

  async deleteMedication(id: string): Promise<boolean> {
    return this.medications.delete(id);
  }

  // Medication log operations
  async getMedicationLogsByProfile(profileId: string): Promise<MedicationLog[]> {
    return Array.from(this.medicationLogs.values()).filter(l => l.profileId === profileId);
  }

  async createMedicationLog(insertLog: InsertMedicationLog): Promise<MedicationLog> {
    const id = randomUUID();
    const log: MedicationLog = { 
      ...insertLog, 
      id,
      takenAt: new Date().toISOString() as any,
    };
    this.medicationLogs.set(id, log);
    return log;
  }

  async deleteMedicationLog(id: string): Promise<boolean> {
    return this.medicationLogs.delete(id);
  }

  // Upload operations
  async getUpload(id: string): Promise<Upload | undefined> {
    return this.uploads.get(id);
  }

  async getUploadsByProfile(profileId: string): Promise<Upload[]> {
    return Array.from(this.uploads.values()).filter(u => u.profileId === profileId);
  }

  async createUpload(insertUpload: InsertUpload): Promise<Upload> {
    const id = randomUUID();
    const upload: Upload = { 
      ...insertUpload, 
      id,
      uploadedAt: new Date().toISOString() as any,
    };
    this.uploads.set(id, upload);
    return upload;
  }

  async deleteUpload(id: string): Promise<boolean> {
    return this.uploads.delete(id);
  }

  // SOS event operations
  async getSosEventsByProfile(profileId: string): Promise<SosEvent[]> {
    return Array.from(this.sosEvents.values()).filter(e => e.profileId === profileId);
  }

  async createSosEvent(insertEvent: InsertSosEvent): Promise<SosEvent> {
    const id = randomUUID();
    const event: SosEvent = { 
      ...insertEvent, 
      id,
      triggeredAt: new Date().toISOString() as any,
    };
    this.sosEvents.set(id, event);
    return event;
  }

  // Chat message operations
  async getChatMessagesByProfile(profileId: string): Promise<ChatMessage[]> {
    return Array.from(this.chatMessages.values())
      .filter(m => m.profileId === profileId)
      .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
  }

  async createChatMessage(insertMessage: InsertChatMessage): Promise<ChatMessage> {
    const id = randomUUID();
    const message: ChatMessage = { 
      ...insertMessage, 
      id,
      timestamp: new Date().toISOString() as any,
    };
    this.chatMessages.set(id, message);
    return message;
  }
}

export const storage = new MemStorage();
