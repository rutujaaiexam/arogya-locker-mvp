import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Profile schema - represents family members
export const profiles = pgTable("profiles", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(), // Links to authenticated user
  name: text("name").notNull(),
  relation: text("relation"), // e.g., "Self", "Mother", "Father", "Child"
  dateOfBirth: text("date_of_birth"),
  bloodType: text("blood_type"),
  allergies: text("allergies").array(),
  emergencyContact: text("emergency_contact"),
  emergencyContactPhone: text("emergency_contact_phone"),
  chronicConditions: text("chronic_conditions").array(),
  currentMedications: text("current_medications"),
  avatarColor: text("avatar_color").notNull(), // For colored initial circles
  isPrimary: boolean("is_primary").default(false),
});

export const insertProfileSchema = createInsertSchema(profiles).omit({
  id: true,
}).extend({
  allergies: z.array(z.string()).optional().default([]),
  chronicConditions: z.array(z.string()).optional().default([]),
});

export type InsertProfile = z.infer<typeof insertProfileSchema>;
export type Profile = typeof profiles.$inferSelect;

// Medication schema - medication schedule tracking
export const medications = pgTable("medications", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  profileId: varchar("profile_id").notNull(),
  name: text("name").notNull(),
  dosage: text("dosage").notNull(),
  frequency: text("frequency").notNull(), // "Morning", "Afternoon", "Evening", "Night"
  time: text("time"), // e.g., "08:00 AM"
  instructions: text("instructions"),
  isActive: boolean("is_active").default(true),
});

export const insertMedicationSchema = createInsertSchema(medications).omit({
  id: true,
});

export type InsertMedication = z.infer<typeof insertMedicationSchema>;
export type Medication = typeof medications.$inferSelect;

// Medication logs - track when medications are taken
export const medicationLogs = pgTable("medication_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  medicationId: varchar("medication_id").notNull(),
  profileId: varchar("profile_id").notNull(),
  takenAt: timestamp("taken_at").defaultNow(),
  date: text("date").notNull(), // YYYY-MM-DD format for easy querying
});

export const insertMedicationLogSchema = createInsertSchema(medicationLogs).omit({
  id: true,
  takenAt: true,
});

export type InsertMedicationLog = z.infer<typeof insertMedicationLogSchema>;
export type MedicationLog = typeof medicationLogs.$inferSelect;

// Upload schema - medical documents/prescriptions
export const uploads = pgTable("uploads", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  profileId: varchar("profile_id").notNull(),
  fileName: text("file_name").notNull(),
  fileType: text("file_type").notNull(), // "prescription", "lab_report", "x_ray", "other"
  fileData: text("file_data").notNull(), // Base64 encoded for localStorage
  uploadedAt: timestamp("uploaded_at").defaultNow(),
  notes: text("notes"),
});

export const insertUploadSchema = createInsertSchema(uploads).omit({
  id: true,
  uploadedAt: true,
});

export type InsertUpload = z.infer<typeof insertUploadSchema>;
export type Upload = typeof uploads.$inferSelect;

// SOS events - emergency button activations
export const sosEvents = pgTable("sos_events", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  profileId: varchar("profile_id").notNull(),
  triggeredAt: timestamp("triggered_at").defaultNow(),
  location: text("location"), // Placeholder for future geolocation
  notes: text("notes"),
});

export const insertSosEventSchema = createInsertSchema(sosEvents).omit({
  id: true,
  triggeredAt: true,
});

export type InsertSosEvent = z.infer<typeof insertSosEventSchema>;
export type SosEvent = typeof sosEvents.$inferSelect;

// Auth/User schema - simplified for demo
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  phone: text("phone").notNull().unique(),
  name: text("name"),
  lastLoginAt: timestamp("last_login_at"),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  lastLoginAt: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Chat messages - for demo chatbot
export const chatMessages = pgTable("chat_messages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  profileId: varchar("profile_id").notNull(),
  message: text("message").notNull(),
  isBot: boolean("is_bot").default(false),
  timestamp: timestamp("timestamp").defaultNow(),
});

export const insertChatMessageSchema = createInsertSchema(chatMessages).omit({
  id: true,
  timestamp: true,
});

export type InsertChatMessage = z.infer<typeof insertChatMessageSchema>;
export type ChatMessage = typeof chatMessages.$inferSelect;
